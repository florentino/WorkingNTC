﻿//using NTC_Consolidator.Model;
using NTC_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmQualifyingCapital : MetroFramework.Forms.MetroForm
    {
        private static frmQualifyingCapital qcapitalform = null;
        public static frmQualifyingCapital Instance()
        {
            if (qcapitalform == null)
            {
                qcapitalform = new frmQualifyingCapital();
            }
            return qcapitalform;
        }

        public frmQualifyingCapital()
        {
            InitializeComponent();
        }

        private void frmQualifyingCapital_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
          
        }

        private void txtAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            decimal x;
            if (ch == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else if (!char.IsDigit(ch) && ch != '.' || !Decimal.TryParse(txtAmount.Text + ch, out x))
            {
                e.Handled = true;
            }
        }

        private bool IsValid(bool isPassed, string description, string amount, QualifyingCapital capital)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(description))
                {
                    capital.Description = "";
                }
                else
                {
                    lblErrDescription.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrDescription.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(amount))
                {
                    capital.Amount = "";
                }
                else
                {
                    lblErrAmount.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrAmount.Text = ex.Message;
                isPassed = false;
            }

            return isPassed;
        }

        private void metroButton2_Click(object sender, EventArgs e)
        {
            var isPassed = false;
            var description = txtDescription.Text;
            var amount = txtAmount.Text;

            #region CorrespondingGL Validation Using EF DataAnnotation

            QualifyingCapital capital = new QualifyingCapital();

            isPassed = IsValid(isPassed, description, amount, capital); //Check for Valid Input

            if (!isPassed)
            {
                return;
            }
            else
            {
                //validate first before saving
                //// var _instance = new NTCService();

                var retval = 0;// _instance.InsertCapital(description, amount, Program.UserName);

                if (retval == 1)//retval == 1 Successfully saved
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Qualifying Capital", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtDescription.Text = "";
                    txtAmount.Text = "";
                }
                else if (retval == 0) //retval == 0 GL Code Already Exist
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nDescription Already Exist in the Database", "Exists", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (retval == 2) //retval == 2 error encountered
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }

            #endregion
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
