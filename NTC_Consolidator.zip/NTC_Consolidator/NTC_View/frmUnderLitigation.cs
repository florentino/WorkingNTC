﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmUnderLitigation : MetroFramework.Forms.MetroForm
    {
        private static frmUnderLitigation litigationform = null;
        private string _icbs = "";
        private string _icbsEXT = "";

        public static frmUnderLitigation Instance()
        {
            if (litigationform == null)
            {
                litigationform = new frmUnderLitigation();
            }
            return litigationform;
        }


        public frmUnderLitigation()
        {
            InitializeComponent();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Text Files(.txt) | *.txt| CSV Files(.csv)|*.csv";


            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                _icbs = Path.GetDirectoryName(dlg.FileName);
                _icbsEXT = Path.GetExtension(dlg.FileName);
                txtFilePath.Text = dlg.FileName;
            }
        }
    }
}
