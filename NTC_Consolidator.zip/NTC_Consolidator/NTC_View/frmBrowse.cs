﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmBrowse : MetroFramework.Forms.MetroForm
    {
        public frmBrowse()
        {
            InitializeComponent();
        }

        private void frmBrowse_Load(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls| Excel Files(.xlsx) | *.xlsx";
           // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;
                frmConsolidator._AafPath = dlg.FileName;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
