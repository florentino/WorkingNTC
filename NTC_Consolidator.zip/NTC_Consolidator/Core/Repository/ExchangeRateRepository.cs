﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace NTC_Consolidator.Core.Repository
{
    public class ExchangeRateRepository : IExchangeRate, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_ExchangeRate> _bjectSet;

        public ExchangeRateRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_ExchangeRate>();
        }


        public void BulkDelete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkUpdete(object objdata)
        {
            throw new NotImplementedException();
        }

        public void DeleteRate(string CurrencyCode)
        {
            try
            {
                var original = context.BDOLF_ExchangeRate.Where(a => a.CurrencyCode == CurrencyCode).First();

                context.BDOLF_ExchangeRate.Remove(original);
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public void DeleteRate(int CurrencyID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_ExchangeRate> GetAll()
        {
            var query = from data in context.BDOLF_ExchangeRate.ToList()
                        select data;

            return query;
        }

        public BDOLF_ExchangeRate GetByCode(string CurrencyCode)
        {
            // var result = uow.ExchangeRateRepository.GetAll().Where(i => i.CurrencyCode == code).FirstOrDefault().CurrencyRate;
            var result = context.BDOLF_ExchangeRate.Where(a => a.CurrencyCode == CurrencyCode && a.isDeleted == false).FirstOrDefault();
            return result;
        }

        public BDOLF_ExchangeRate GetByID(int CurrencyCode)
        {
            throw new NotImplementedException();
        }

        public void InsertRate(BDOLF_ExchangeRate rate)
        {
            context.Set<BDOLF_ExchangeRate>().Add(rate);
            context.SaveChanges();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateRate(BDOLF_ExchangeRate rate)
        {
                var original = context.BDOLF_ExchangeRate.Find(rate.CurrencyID);
                original.CurrencyCode = rate.CurrencyCode;
                original.CurrencyRate = rate.CurrencyRate;
                original.DateTimeRate = rate.DateTimeRate;
                original.CreatedBy = rate.CreatedBy;
                original.CreatedDate = rate.CreatedDate;

                context.Entry<BDOLF_ExchangeRate>(context.Set<BDOLF_ExchangeRate>().Find(rate.CurrencyID)).CurrentValues.SetValues(original);
                context.SaveChanges();
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
