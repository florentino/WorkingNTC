﻿using NTC_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.Data;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface ICorrespondingGLRepository : IDisposable
    {
        IEnumerable<CorrespondingGL> GetGL();
        CorrespondingGL GetCorrespondingGLByID(int glID);
        CorrespondingGL GetCorrespondingGLByID(string glID);
        void InsertCorrespondingGL(CorrespondingGL gl);
        void DeleteCorrespondingGL(int glID);
        void DeleteCorrespondingGL(string glID);
        void UpdateCorrespondingGL(CorrespondingGL gl);
        void BulkInsert(object objdata);
        void BulkDelete(object objdata);
        void BulkUpdete(object objdata);
        void Save();
    }
}
