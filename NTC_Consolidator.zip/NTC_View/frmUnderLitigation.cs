﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.NTC_Model;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmUnderLitigation : MetroFramework.Forms.MetroForm
    {
        DataTable dtAaf;
        DataTable dtFams;
        DataTable dtupdated = new DataTable("Updated");
        DataTable dtinserted = new DataTable("Inserted");
        DataRow dru = null;
        DataRow dri = null;

        private static frmUnderLitigation litigationform = null;
        private ICorrespondingGLRepository correspondingGLRepository;
        private IUnderLitigation underLitigationRepository;
        private string _underLitigation = "";
        string underLitigationFileName = "";
        private string _underLitigationEXT = "";
        private DateTime _underLitigationDateParameter;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtunderLitigation;
        DataTable dtRecords = new DataTable();
        string[] progressArray = new string[5];

        public static frmUnderLitigation Instance()
        {
            if (litigationform == null)
            {
                litigationform = new frmUnderLitigation();
            }
            return litigationform;
        }

        public frmUnderLitigation()
        {
            InitializeComponent();
            this.underLitigationRepository = new UnderLitigationRepository(new NTC_Context_Entities());
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTC_Context_Entities());
            lblBusy.Text = "";

            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            pnlSummary.Location = new Point(
           this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            pnlSummary.Visible = false;

            pnlInsertUpdate.Location = new Point(
          this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
          this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            pnlInsertUpdate.Visible = false;

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                dtunderLitigation = new DataTable();

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        private DataTable FaMSDataTable()
        {
            dtFams = new DataTable("FAMSDATA");

            dtFams.Columns.Add("system");
            dtFams.Columns.Add("recorddate");
            dtFams.Columns.Add("reason");
            dtFams.Columns.Add("rawfiles");
            dtFams.Columns.Add("isdeleted");
            dtFams.Columns.Add("username");
            dtFams.Columns.Add("transdate");
            dtFams.Columns.Add("isconsolidated");
            dtFams.Columns.Add("accountno");
            dtFams.Columns.Add("clientname");
            dtFams.Columns.Add("ao");
            dtFams.Columns.Add("statuspersystem");
            dtFams.Columns.Add("valuedate");
            dtFams.Columns.Add("maturitydate");
            dtFams.Columns.Add("totalloan");
            dtFams.Columns.Add("ob");
            dtFams.Columns.Add("monthlyob");
            dtFams.Columns.Add("clientsequity");
            dtFams.Columns.Add("accruedinterestreceivable");
            dtFams.Columns.Add("originalrate");
            dtFams.Columns.Add("currentrate");
            dtFams.Columns.Add("terminmonths");
            dtFams.Columns.Add("perfamsaaficbsindustrycode");
            dtFams.Columns.Add("industryheader");
            dtFams.Columns.Add("industrydetail");
            dtFams.Columns.Add("perfamsaaficbsassetsizeinwords");
            dtFams.Columns.Add("nextratereviewdateextractedperfamsaaficbs");
            dtFams.Columns.Add("previousmonthsnpltaggingbyrisk");
            dtFams.Columns.Add("specificrequiredprovisions");
            dtFams.Columns.Add("generalrequiredprovisions");

            var startRow = 0;
            DataRow dr = null;
            foreach (DataRow row in dtunderLitigation.Rows)
            {
                dr = dtAaf.NewRow();

                dr["system"] = "FAMS";
                dr["accountno"] = dtunderLitigation.Rows[startRow]["clientcode"].ToString();
                dr["clientname"] = dtunderLitigation.Rows[startRow]["clientname"].ToString();
                dr["ao"] = dtunderLitigation.Rows[startRow]["accountofficer"].ToString();
                dr["statuspersystem"] = dtunderLitigation.Rows[startRow]["status"].ToString();
                dr["valuedate"] = dtunderLitigation.Rows[startRow]["from"].ToString();
                dr["maturitydate"] = dtunderLitigation.Rows[startRow]["to"].ToString();
                dr["totalloan"] = dtunderLitigation.Rows[startRow]["investmentlimit"].ToString();
                dr["ob"] = dtunderLitigation.Rows[startRow]["receivables"].ToString();
                dr["monthlyob"] = dtunderLitigation.Rows[startRow]["receivables"].ToString();
                dr["clientsequity"] = dtunderLitigation.Rows[startRow]["clientsequityOfUnpaidInvoices"].ToString();
                dr["accruedinterestreceivable"] = dtunderLitigation.Rows[startRow]["discountChargeaccrual"].ToString();
                dr["originalrate"] = dtunderLitigation.Rows[startRow]["currentdc"].ToString();
                dr["currentrate"] = dtunderLitigation.Rows[startRow]["currentdc"].ToString();
                dr["terminmonths"] = dtunderLitigation.Rows[startRow]["creditterm"].ToString();
                dr["perfamsaaficbsindustrycode"] = dtunderLitigation.Rows[startRow]["industrycode"].ToString();
                dr["industryheader"] = dtunderLitigation.Rows[startRow]["industrydetailsdescription"].ToString();
                dr["industrydetail"] = dtunderLitigation.Rows[startRow]["industrydetailsdescription"].ToString();
                dr["perfamsaaficbsassetsizeinwords"] = dtunderLitigation.Rows[startRow]["sizeoffirmassetsize"].ToString();
                dr["nextratereviewdateextractedperfamsaaficbs"] = dtunderLitigation.Rows[startRow]["reviewdate"].ToString();
                dr["previousmonthsnpltaggingbyrisk"] = "";
                dr["specificrequiredprovisions"] = "";
                dr["generalrequiredprovisions"] = "";
                dr["recorddate"] = _underLitigationDateParameter;
                //dr["reason"] = "";
                dr["rawfiles"] = txtFilePath.Text;
                //dr["isDeleted"] = false;
                //dr["isConsolidated"] = true;
                dr["UserName"] = frmConsolidator.UserName;
                dr["transdate"] = DateTime.Now.ToShortDateString();

            }
            return dtFams;
        }

        private DataTable AAFDataTable()
        {
            dtAaf = new DataTable("AAFDATA");

            dtAaf.Columns.Add("system");
            dtAaf.Columns.Add("accountno");
            dtAaf.Columns.Add("clientname");
            dtAaf.Columns.Add("ao");
            dtAaf.Columns.Add("facilitycode");
            dtAaf.Columns.Add("statuspersystem");
            dtAaf.Columns.Add("valuedate");
            dtAaf.Columns.Add("firstduedate");
            dtAaf.Columns.Add("maturitydate");
            dtAaf.Columns.Add("totalloan");
            dtAaf.Columns.Add("ob");
            dtAaf.Columns.Add("monthlyob");
            dtAaf.Columns.Add("udibalance");
            dtAaf.Columns.Add("origerv");
            dtAaf.Columns.Add("pvrv");
            dtAaf.Columns.Add("origgd");
            dtAaf.Columns.Add("pvgd");
            dtAaf.Columns.Add("originalrate");
            dtAaf.Columns.Add("currentrate");
            dtAaf.Columns.Add("terminmonths");
            dtAaf.Columns.Add("remainingterminmonths");
            dtAaf.Columns.Add("originalamortizationaaf");
            dtAaf.Columns.Add("paymentscheduleamortizationaaf");
            dtAaf.Columns.Add("repriceddate");
            dtAaf.Columns.Add("aaficbsratetype");
            dtAaf.Columns.Add("repricedamortization");
            dtAaf.Columns.Add("pastduedateitldateextractedperaaficbs");
            dtAaf.Columns.Add("perfamsaaficbsindustrycode");
            dtAaf.Columns.Add("industryheader");
            dtAaf.Columns.Add("industrydetail");
            dtAaf.Columns.Add("collateral");
            dtAaf.Columns.Add("perfamsaaficbsassetsizeinwords");
            dtAaf.Columns.Add("icbsglcode");
            dtAaf.Columns.Add("icbsglname");
            dtAaf.Columns.Add("costcenter");
            dtAaf.Columns.Add("branchnameofcostcenterpersystem");
            dtAaf.Columns.Add("originatingbranchbooked");
            dtAaf.Columns.Add("nationalitypericbs");
            dtAaf.Columns.Add("nextratereviewdateextractedperfamsaaficbs");
            dtAaf.Columns.Add("taxid");
            dtAaf.Columns.Add("customertypedescription");
            dtAaf.Columns.Add("relcode");
            dtAaf.Columns.Add("reecode");
            dtAaf.Columns.Add("reeaddtlinfo");
            dtAaf.Columns.Add("acctref");
            dtAaf.Columns.Add("rpt");
            dtAaf.Columns.Add("assetcost");
            dtAaf.Columns.Add("leasetype");
            dtAaf.Columns.Add("icbscollateralcode");
            dtAaf.Columns.Add("assetvalue");
            dtAaf.Columns.Add("approvedamount");
            dtAaf.Columns.Add("cpnumber");
            dtAaf.Columns.Add("lastprincipalpay");
            dtAaf.Columns.Add("principalpaydate");
            dtAaf.Columns.Add("lastinterestpay");
            dtAaf.Columns.Add("lastinterestpaydate");
            dtAaf.Columns.Add("previousmonthsnpltaggingbyrisk");
            dtAaf.Columns.Add("specificrequiredprovisions");
            dtAaf.Columns.Add("generalrequiredprovisions");

            var startRow = 0;
            DataRow dr = null;
            foreach (DataRow row in dtunderLitigation.Rows)
            {
                dr = dtAaf.NewRow();

                dr["system"] = "AAF";
                dr["accountno"] = dtunderLitigation.Rows[startRow]["accountno"].ToString();
                dr["clientname"] = dtunderLitigation.Rows[startRow]["clientname"].ToString();
                dr["ao"] = dtunderLitigation.Rows[startRow]["ao"].ToString();
                dr["facilitycode"] = dtunderLitigation.Rows[startRow]["facilitycode"].ToString();
                dr["statuspersystem"] = dtunderLitigation.Rows[startRow]["statuspersystem"].ToString();
                dr["valuedate"] = dtunderLitigation.Rows[startRow]["valuedate"].ToString();
                dr["firstduedate"] = dtunderLitigation.Rows[startRow]["firstduedate"].ToString();
                dr["maturitydate"] = dtunderLitigation.Rows[startRow]["maturitydate"].ToString();
                dr["totalloan"] = dtunderLitigation.Rows[startRow]["totalloan"].ToString();
                dr["ob"] = dtunderLitigation.Rows[startRow]["ob"].ToString();
                dr["monthlyob"] = dtunderLitigation.Rows[startRow]["monthlyob"].ToString();
                dr["udibalance"] = dtunderLitigation.Rows[startRow]["udibalance"].ToString();
                dr["origerv"] = dtunderLitigation.Rows[startRow]["origerv"].ToString();
                dr["pvrv"] = dtunderLitigation.Rows[startRow]["pvrv"].ToString();
                dr["origgd"] = dtunderLitigation.Rows[startRow]["origgd"].ToString();
                dr["pvgd"] = dtunderLitigation.Rows[startRow]["pvgd"].ToString();
                dr["originalrate"] = dtunderLitigation.Rows[startRow]["originalrate"].ToString();
                dr["currentrate"] = dtunderLitigation.Rows[startRow]["currentrate"].ToString();
                dr["terminmonths"] = dtunderLitigation.Rows[startRow]["terminmonths"].ToString();
                dr["remainingterminmonths"] = dtunderLitigation.Rows[startRow]["remainingterminmonths"].ToString();
                dr["originalamortizationaaf"] = dtunderLitigation.Rows[startRow]["originalamortizationaaf"].ToString();
                dr["paymentscheduleamortizationaaf"] = dtunderLitigation.Rows[startRow]["paymentscheduleamortizationaaf"].ToString();
                dr["repriceddate"] = dtunderLitigation.Rows[startRow]["repriceddate"].ToString();
                dr["aaficbsratetype"] = dtunderLitigation.Rows[startRow]["aaficbsratetype"].ToString();
                dr["repricedamortization"] = dtunderLitigation.Rows[startRow]["repricedamortization"].ToString();
                dr["pastduedateitldateextractedperaaficbs"] = dtunderLitigation.Rows[startRow]["pastduedateitldateextractedperaaficbs"].ToString();
                dr["perfamsaaficbsindustrycode"] = dtunderLitigation.Rows[startRow]["perfamsaaficbsindustrycode"].ToString();
                dr["industryheader"] = dtunderLitigation.Rows[startRow]["industryheader"].ToString();
                dr["industrydetail"] = dtunderLitigation.Rows[startRow]["industrydetail"].ToString();
                dr["collateral"] = dtunderLitigation.Rows[startRow]["collateral"].ToString();
                dr["perfamsaaficbsassetsizeinwords"] = dtunderLitigation.Rows[startRow]["perfamsaaficbsassetsizeinwords"].ToString();
                dr["icbsglcode"] = dtunderLitigation.Rows[startRow]["icbsglcode"].ToString();
                dr["icbsglname"] = dtunderLitigation.Rows[startRow]["icbsglname"].ToString();
                dr["costcenter"] = dtunderLitigation.Rows[startRow]["costcenter"].ToString();
                dr["branchnameofcostcenterpersystem"] = dtunderLitigation.Rows[startRow]["branchnameofcostcenterpersystem"].ToString();
                dr["originatingbranchbooked"] = dtunderLitigation.Rows[startRow]["originatingbranchbooked"].ToString();
                dr["nationalitypericbs"] = dtunderLitigation.Rows[startRow]["nationalitypericbs"].ToString();
                dr["nextratereviewdateextractedperfamsaaficbs"] = dtunderLitigation.Rows[startRow]["nextratereviewdateextractedperfamsaaficbs"].ToString();
                dr["taxid"] = dtunderLitigation.Rows[startRow]["taxid"].ToString();
                dr["customertypedescription"] = dtunderLitigation.Rows[startRow]["customertypedescription"].ToString();
                dr["relcode"] = dtunderLitigation.Rows[startRow]["relcode"].ToString();
                dr["reecode"] = dtunderLitigation.Rows[startRow]["reecode"].ToString();
                dr["reeaddtlinfo"] = dtunderLitigation.Rows[startRow]["reeaddtlinfo"].ToString();
                dr["acctref"] = dtunderLitigation.Rows[startRow]["acctref"].ToString();
                dr["rpt"] = dtunderLitigation.Rows[startRow]["rpt"].ToString();
                dr["assetcost"] = dtunderLitigation.Rows[startRow]["assetcost"].ToString();
                dr["leasetype"] = dtunderLitigation.Rows[startRow]["leasetype"].ToString();
                dr["icbscollateralcode"] = dtunderLitigation.Rows[startRow]["icbscollateralcode"].ToString();
                dr["assetvalue"] = dtunderLitigation.Rows[startRow]["assetvalue"].ToString();
                dr["approvedamount"] = dtunderLitigation.Rows[startRow]["approvedamount"].ToString();
                dr["cpnumber"] = dtunderLitigation.Rows[startRow]["cpnumber"].ToString();
                dr["lastprincipalpay"] = dtunderLitigation.Rows[startRow]["lastprincipalpay"].ToString();
                dr["principalpaydate"] = dtunderLitigation.Rows[startRow]["principalpaydate"].ToString();
                dr["lastinterestpay"] = dtunderLitigation.Rows[startRow]["lastinterestpay"].ToString();
                dr["lastinterestpaydate"] = dtunderLitigation.Rows[startRow]["lastinterestpaydate"].ToString();
                dr["previousmonthsnpltaggingbyrisk"] = dtunderLitigation.Rows[startRow]["previousmonthsnpltaggingbyrisk"].ToString();
                dr["specificrequiredprovisions"] = dtunderLitigation.Rows[startRow]["specificrequiredprovisions"].ToString();
                dr["generalrequiredprovisions"] = dtunderLitigation.Rows[startRow]["generalrequiredprovisions"].ToString();
                //dr["reason"] = "";
                dr["rawfiles"] = txtFilePath.Text;
                //dr["isDeleted"] = false;
                //dr["isConsolidated"] = true;
                dr["UserName"] = frmConsolidator.UserName;
                dr["transdate"] = DateTime.Now.ToShortDateString();
                dr["recorddate"] = _underLitigationDateParameter;
            }

            return dtAaf;
        }
        
        private void frmUnderLitigation_Load(object sender, EventArgs e)
        {
            if (txtFilePath.Text == "") btnExecute.Enabled = false;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";


            //qualifyingCapitalRepository.GetAll(); 

            //dtunderLitigation = (this.dgvAccountUnderLit.DataSource as DataTable).Copy();
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";
            lblBusy.Text = "";
            lblWaitStatus.Text = string.Format("Status: Completed");

            ListItem();

            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();

        }

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";
            //lblWaitStatus.Text = labelsreports[2];

            lblWaitInfo.Text = labelsreports[1];
            //lblWaitStatus.Text = string.Format("Status: Reading in row {0} at column {1} out of {2} rows", curRow, labelsreports[3], lineCount);
            //lblWaitStatus.Text = string.Format("Status: Reading at row {0} out of {1}", curRow, lineCount);
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                dgvAccountUnderLit.DataSource = dtunderLitigation;
                dgvAccountUnderLit.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                lblInfo.Text = "Total Records: " + dtunderLitigation.Rows.Count.ToString();


                FaMSDataTable();
                AAFDataTable();

                pnlWaitInfo.Visible = false;


                btnExecute.Enabled = dgvAccountUnderLit.Rows.Count > 0 ? true : false;
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                underLitigationFileName = Path.GetFileName(txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "] WHERE [F1] <> ''", conn);
                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);
                    var colDate = Convert.ToDateTime(dtold.Rows[0][0].ToString().Substring(61)).ToShortDateString().ToString(); //Get As Of DATE of generated File
                    _underLitigationDateParameter = Convert.ToDateTime(colDate.ToString());
                    dtold.Rows.RemoveAt(0);
                    //Convert Row 3 value as a header of the DataTable
                    foreach (DataColumn dc in dtold.Columns)
                    {
                        var _name = dtold.Rows[0][dc].ToString();
                        var NewHeader = Regex.Replace(_name, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToLower();
                        
                        dc.ColumnName = dtold.Rows[0][dc].ToString().ToLower();
                    }
                    dtold.Rows.RemoveAt(0);

                    var lastRow = dtold.Rows.Count - 1;

                    var isVersion = dtold.Rows[lastRow]["AccountNo"].ToString().Contains("ver") ? true : false;

                    if (isVersion) dtold.Rows.RemoveAt(lastRow);

                    dtunderLitigation = dtold;
                }
            }
            catch (Exception ex)
            {
                txtFilePath.Text = "";
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }

        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2];
            lblWaitInfo.Text = labelsreports[1];
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";
                MetroMessageBox.Show(this, "\r\nData was successfully added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            string glCode;
            string glName;
            bool bFlag;

            try
            {
                var iCount = 0;
                foreach (DataRow dritem in dtunderLitigation.Rows)
                {
                    BDOLF_Consolidator data = new BDOLF_Consolidator();

                    var _System = "ICBS"; //Find the record where system is not ICBS
                    var _AccountNo = dritem["AccountNo"].ToString();


                    progressArray[0] = (iCount * 100 / dtunderLitigation.Rows.Count).ToString(); // percent
                    progressArray[1] = "Validating AccountNo if Exists, Please wait..."; //header text
                    progressArray[2] = "Status: Updating the record for the AccountNo: " + _AccountNo; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column


                    data.RawFiles = txtFilePath.Text;
                    data.isConsolidated = true;
                    data.isDeleted = false;
                    data.UserName = frmConsolidator.UserName;
                    data.TransDate = DateTime.Now.ToShortDateString();
                    data.RecordDate = _underLitigationDateParameter;
                    data.SYSTEM = _System;
                    data.AccountNo = dritem["AccountNo"].ToString();
                    data.ClientName = dritem["Client Name"].ToString();
                    data.AO = dritem["AO"].ToString();
                    data.FacilityCode = dritem["FacilityCode"].ToString();
                    data.StatusPerSystem = dritem["StatusPerSystem"].ToString();
                    data.ValueDate = dritem["ValueDate"].ToString();
                    data.FirstDueDate = dritem["FirstDueDate"].ToString();
                    data.MaturityDate = dritem["MaturityDate"].ToString();
                    data.TotalLoan = dritem["TotalLoan"].ToString();
                    data.OB = dritem["OB"].ToString();
                    data.MonthlyOB = dritem["MonthlyOB"].ToString();
                    data.UDIBalance = dritem["UDIBalance"].ToString();
                    data.ClientsEquity = dritem["ClientsEquity"].ToString();
                    data.AccruedInterestReceivable = dritem["AccruedInterestReceivable"].ToString();
                    data.OrigERV = dritem["OrigERV"].ToString();
                    data.PVRV = dritem["PVRV"].ToString();
                    data.OrigGD = dritem["OrigGD"].ToString();
                    data.PVGD = dritem["PVGD"].ToString();
                    data.TotalLoanPortfolio = dritem["TotalLoanPortfolio"].ToString();
                    data.NTC = dritem["NTC"].ToString();
                    data.OriginalRate = dritem["OriginalRate"].ToString();
                    data.CurrentRate = dritem["CurrentRate"].ToString();
                    data.TermInMonths = dritem["TermInMonths"].ToString();
                    data.RemainingTermInMonths = dritem["RemainingTermInMonths"].ToString();
                    data.OriginalAmortizationAAF = dritem["OriginalAmortizationAAF"].ToString();
                    data.PaymentScheduleAmortizationAAF = dritem["PaymentScheduleAmortizationAAF"].ToString();
                    data.RepricedDate = dritem["RepricedDate"].ToString();
                    data.AAFICBSRateType = dritem["AAFICBSRateType"].ToString();
                    data.RepricedAmortization = dritem["RepricedAmortization"].ToString();
                    data.PastDueDateITLDateExtractedPerAAFICBS = dritem["PastDueDateITLDateExtractedPerAAFICBS"].ToString();
                    data.PerFaMSAAFICBSIndustryCode = dritem["PerFaMSAAFICBSIndustryCode"].ToString();
                    data.IndustryHeader = dritem["IndustryHeader"].ToString();
                    data.IndustryDetail = dritem["IndustryDetail"].ToString();
                    data.Collateral = dritem["Collateral"].ToString();
                    data.PerFaMSAAFICBSAssetSize = dritem["PerFaMSAAFICBSAssetSize"].ToString();
                    data.PerFaMSAAFICBSAssetSizeInWords = dritem["PerFaMSAAFICBSAssetSizeInWords"].ToString();
                    data.ICBSGLCode = dritem["ICBSGLCode"].ToString();
                    data.ICBSGLName = dritem["ICBSGLName"].ToString();
                    data.CostCenter = dritem["CostCenter"].ToString();
                    data.BranchNameOfCostCenterPerSystem = dritem["BranchNameOfCostCenterPerSystem"].ToString();
                    data.StatusPerGL = dritem["StatusPerGL"].ToString();
                    data.OriginatingBranchBooked = dritem["OriginatingBranchBooked"].ToString();
                    data.NationalityPerICBS = dritem["NationalityPerICBS"].ToString();
                    data.NextRateReviewDateExtractedPerFaMSAAFICBS = dritem["NextRateReviewDateExtractedPerFaMSAAFICBS"].ToString();
                    data.TaxID = dritem["TaxID"].ToString();
                    data.LoanPurposeCode = dritem["LoanPurposeCode"].ToString();
                    data.MaturityTypeCode = dritem["MaturityTypeCode"].ToString();
                    data.BankRelationship = dritem["BankRelationship"].ToString();
                    data.SyndicatedLoanInd = dritem["SyndicatedLoanInd"].ToString();
                    data.CustomerTypeDescription = dritem["CustomerTypeDescription"].ToString();
                    data.RELCode = dritem["RELCode"].ToString();
                    data.REECode = dritem["REECode"].ToString();
                    data.REEAddtlInfo = dritem["REEAddtlInfo"].ToString();
                    data.AcctRef = dritem["AcctRef"].ToString();
                    data.RPT = dritem["RPT"].ToString();
                    data.ASSETCOST = dritem["ASSETCOST"].ToString();
                    data.LeaseType = dritem["LeaseType"].ToString();
                    data.Provisioning = dritem["Provisioning"].ToString();
                    data.Matrix = dritem["Matrix"].ToString();
                    data.Remarks = dritem["Remarks"].ToString();
                    data.ICBSCollateralCode = dritem["ICBSCollateralCode"].ToString();
                    data.AssetValue = dritem["AssetValue"].ToString();
                    data.ApprovedAmount = dritem["ApprovedAmount"].ToString();
                    data.CPNumber = dritem["CPNumber"].ToString();
                    data.LastPrincipalPay = dritem["LastPrincipalPay"].ToString();
                    data.PrincipalPayDate = dritem["PrincipalPayDate"].ToString();
                    data.LastInterestPay = dritem["LastInterestPay"].ToString();
                    data.LastInterestPayDate = dritem["LastInterestPayDate"].ToString();
                    data.PreviousMonthsNPLTaggingByRisk = dritem["PreviousMonthsNPLTaggingByRisk"].ToString();
                    data.SpecificRequiredProvisions = dritem["SpecificRequiredProvisions"].ToString();
                    data.GeneralRequiredProvisions = dritem["GeneralRequiredProvisions"].ToString();
                    data.Reason = dritem["Reason"].ToString();

                    if (underLitigationRepository.AccountNotExists(_AccountNo, _underLitigationDateParameter.ToString()))
                    {
                        underLitigationRepository.UpdateConsolidator(data);

                        dru = dtupdated.NewRow();
                        dru["AccountNo"] = data.AccountNo;
                        dru["GL Code"] = data.ICBSGLCode;
                        dru["GL Description"] = data.ICBSGLName;
                    }
                    else
                    {
                        underLitigationRepository.InsertRecord(data);

                        dri = dtinserted.NewRow();
                        dri["AccountNo"] = data.AccountNo;
                        dri["GL Code"] = data.ICBSGLCode;
                        dri["GL Description"] = data.ICBSGLName;
                    }

                    saveWorker.ReportProgress(iCount++ * 100 / dtunderLitigation.Rows.Count); // wla lng
                }
            }
            catch (Exception ex)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //MetroMessageBox.Show(new Form() { TopMost = true }, "\r\nFaMS RAW File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else
                {
                    //oledbConn.Close();
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //MetroMessageBox.Show(new Form() { TopMost = true }, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }

        private void ListItem()
        {
            dtupdated.Columns.Add("AccountNo");
            dtupdated.Columns.Add("GL Code");
            dtupdated.Columns.Add("GL Description");

            dtinserted.Columns.Add("AccountNo");
            dtinserted.Columns.Add("GL Code");
            dtinserted.Columns.Add("GL Description");



        }

        private void frmUnderLitigation_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmUnderLitigation.litigationform = null;
        }

        private void lblOutOf_Click(object sender, EventArgs e)
        {

        }

        private void lnkDetails_DoubleClick(object sender, EventArgs e)
        {
            pnlInsertUpdate.Visible = true;
        }

        private void btnpnlUpdateInsert_Click(object sender, EventArgs e)
        {
            this.pnlInsertUpdate.Visible = false;
        }

        private void ShowHiddenPanel()
        {
            pnlInsertUpdate.Visible = true;
            //loop here
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.pnlSummary.Visible = false;
        }

        private void lnkDetailsInserted_DoubleClick(object sender, EventArgs e)
        {
            ShowHiddenPanel();
        }
    }
}
