﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmConsolidator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConsolidator));
            this.btnGenerate = new MetroFramework.Controls.MetroButton();
            this.btnSearch = new MetroFramework.Controls.MetroButton();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvConsolidator = new MetroFramework.Controls.MetroGrid();
            this.txtSearch = new MetroFramework.Controls.MetroTextBox();
            this.lblBusy = new MetroFramework.Controls.MetroLabel();
            this.btnCancel = new MetroFramework.Controls.MetroButton();
            this.lblInfo = new System.Windows.Forms.Label();
            this.pnlWaitInfo = new System.Windows.Forms.Panel();
            this.lblWaitStatus1 = new MetroFramework.Controls.MetroLabel();
            this.lblWaitFilePath = new MetroFramework.Controls.MetroLabel();
            this.lblWaitStatus = new MetroFramework.Controls.MetroLabel();
            this.lblWaitInfo = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ConsoMenu = new System.Windows.Forms.ToolStrip();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.accountUnderLitigationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aAFMigratedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aPLFromRiskToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dailyGLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.faMSPastDueAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.exportToExcelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripDropDownButton();
            this.qualifyingTableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSDollarExchangeRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gLCodeAndDescriptionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setRawFilePathToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.nTCConsolidatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exchangeRateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.migratedAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qualifyingCapitalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountUnderLitigationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.correspondingGLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConsolidator)).BeginInit();
            this.pnlWaitInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.ConsoMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnGenerate
            // 
            this.btnGenerate.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnGenerate.Location = new System.Drawing.Point(1100, 570);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(75, 23);
            this.btnGenerate.TabIndex = 45;
            this.btnGenerate.Text = "&Consolidate";
            this.btnGenerate.UseCustomBackColor = true;
            this.btnGenerate.UseCustomForeColor = true;
            this.btnGenerate.UseSelectable = true;
            this.btnGenerate.UseStyleColors = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackgroundImage = global::NTC_Consolidator.Properties.Resources.sync;
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.Location = new System.Drawing.Point(1143, 82);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(32, 32);
            this.btnSearch.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSearch.TabIndex = 32;
            this.btnSearch.Tag = "Refresh";
            this.btnSearch.UseCustomBackColor = true;
            this.btnSearch.UseCustomForeColor = true;
            this.btnSearch.UseSelectable = true;
            this.btnSearch.UseStyleColors = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.dgvConsolidator);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(23, 115);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1152, 421);
            this.metroPanel1.TabIndex = 33;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvConsolidator
            // 
            this.dgvConsolidator.AllowUserToAddRows = false;
            this.dgvConsolidator.AllowUserToDeleteRows = false;
            this.dgvConsolidator.AllowUserToResizeRows = false;
            this.dgvConsolidator.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvConsolidator.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvConsolidator.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvConsolidator.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvConsolidator.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvConsolidator.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvConsolidator.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvConsolidator.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvConsolidator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvConsolidator.EnableHeadersVisualStyles = false;
            this.dgvConsolidator.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvConsolidator.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvConsolidator.Location = new System.Drawing.Point(0, 0);
            this.dgvConsolidator.Name = "dgvConsolidator";
            this.dgvConsolidator.ReadOnly = true;
            this.dgvConsolidator.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvConsolidator.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvConsolidator.RowHeadersVisible = false;
            this.dgvConsolidator.RowHeadersWidth = 150;
            this.dgvConsolidator.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvConsolidator.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvConsolidator.Size = new System.Drawing.Size(1150, 419);
            this.dgvConsolidator.Style = MetroFramework.MetroColorStyle.Blue;
            this.dgvConsolidator.TabIndex = 10;
            this.dgvConsolidator.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dgvConsolidator.UseCustomBackColor = true;
            this.dgvConsolidator.UseCustomForeColor = true;
            this.dgvConsolidator.UseStyleColors = true;
            // 
            // txtSearch
            // 
            // 
            // 
            // 
            this.txtSearch.CustomButton.AutoEllipsis = true;
            this.txtSearch.CustomButton.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.txtSearch.CustomButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.txtSearch.CustomButton.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSearch.CustomButton.Image = null;
            this.txtSearch.CustomButton.Location = new System.Drawing.Point(414, 2);
            this.txtSearch.CustomButton.Name = "";
            this.txtSearch.CustomButton.Size = new System.Drawing.Size(27, 27);
            this.txtSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearch.CustomButton.TabIndex = 1;
            this.txtSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearch.CustomButton.UseSelectable = true;
            this.txtSearch.CustomButton.Visible = false;
            this.txtSearch.DisplayIcon = true;
            this.txtSearch.Lines = new string[0];
            this.txtSearch.Location = new System.Drawing.Point(700, 82);
            this.txtSearch.MaxLength = 32767;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.PasswordChar = '\0';
            this.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearch.SelectedText = "";
            this.txtSearch.SelectionLength = 0;
            this.txtSearch.SelectionStart = 0;
            this.txtSearch.Size = new System.Drawing.Size(444, 32);
            this.txtSearch.TabIndex = 31;
            this.txtSearch.UseSelectable = true;
            this.txtSearch.WaterMark = "Enter Keyword By: System | AccounNo | ClientName | GLCode | UserName";
            this.txtSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            this.txtSearch.Click += new System.EventHandler(this.txtSearch_Click);
            // 
            // lblBusy
            // 
            this.lblBusy.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblBusy.ForeColor = System.Drawing.Color.Red;
            this.lblBusy.Location = new System.Drawing.Point(26, 552);
            this.lblBusy.Name = "lblBusy";
            this.lblBusy.Size = new System.Drawing.Size(349, 21);
            this.lblBusy.TabIndex = 40;
            this.lblBusy.Text = "[busy status]";
            this.lblBusy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBusy.UseCustomForeColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnCancel.Location = new System.Drawing.Point(1206, 583);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 1;
            this.btnCancel.Text = "&Cancel";
            this.btnCancel.UseCustomBackColor = true;
            this.btnCancel.UseCustomForeColor = true;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.UseStyleColors = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(23, 539);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(92, 13);
            this.lblInfo.TabIndex = 46;
            this.lblInfo.Text = "Total Records: ??";
            // 
            // pnlWaitInfo
            // 
            this.pnlWaitInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlWaitInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus1);
            this.pnlWaitInfo.Controls.Add(this.lblWaitFilePath);
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus);
            this.pnlWaitInfo.Controls.Add(this.lblWaitInfo);
            this.pnlWaitInfo.Controls.Add(this.pictureBox1);
            this.pnlWaitInfo.Location = new System.Drawing.Point(1207, 237);
            this.pnlWaitInfo.Name = "pnlWaitInfo";
            this.pnlWaitInfo.Size = new System.Drawing.Size(326, 117);
            this.pnlWaitInfo.TabIndex = 49;
            // 
            // lblWaitStatus1
            // 
            this.lblWaitStatus1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus1.Location = new System.Drawing.Point(3, 156);
            this.lblWaitStatus1.Name = "lblWaitStatus1";
            this.lblWaitStatus1.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus1.TabIndex = 4;
            this.lblWaitStatus1.Text = "Total Numbers of Records:";
            this.lblWaitStatus1.Visible = false;
            // 
            // lblWaitFilePath
            // 
            this.lblWaitFilePath.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitFilePath.Location = new System.Drawing.Point(3, 175);
            this.lblWaitFilePath.Name = "lblWaitFilePath";
            this.lblWaitFilePath.Size = new System.Drawing.Size(322, 19);
            this.lblWaitFilePath.TabIndex = 3;
            this.lblWaitFilePath.Text = "File Path:";
            this.lblWaitFilePath.Visible = false;
            // 
            // lblWaitStatus
            // 
            this.lblWaitStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus.Location = new System.Drawing.Point(3, 91);
            this.lblWaitStatus.Name = "lblWaitStatus";
            this.lblWaitStatus.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus.TabIndex = 2;
            this.lblWaitStatus.Text = "Status: ";
            // 
            // lblWaitInfo
            // 
            this.lblWaitInfo.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitInfo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblWaitInfo.Location = new System.Drawing.Point(3, 60);
            this.lblWaitInfo.Name = "lblWaitInfo";
            this.lblWaitInfo.Size = new System.Drawing.Size(318, 23);
            this.lblWaitInfo.TabIndex = 1;
            this.lblWaitInfo.Text = "Reading ICBS Raw File, Please Wait...";
            this.lblWaitInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::NTC_Consolidator.Properties.Resources.lg_discuss_ellipsis_preloader;
            this.pictureBox1.Location = new System.Drawing.Point(3, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.ConsoMenu);
            this.panel1.Location = new System.Drawing.Point(23, 82);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(368, 28);
            this.panel1.TabIndex = 50;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(359, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 27);
            this.panel2.TabIndex = 51;
            // 
            // ConsoMenu
            // 
            this.ConsoMenu.BackColor = System.Drawing.Color.Transparent;
            this.ConsoMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ConsoMenu.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.ConsoMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripButton1});
            this.ConsoMenu.Location = new System.Drawing.Point(0, 0);
            this.ConsoMenu.Name = "ConsoMenu";
            this.ConsoMenu.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.ConsoMenu.Size = new System.Drawing.Size(368, 28);
            this.ConsoMenu.TabIndex = 1;
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.accountUnderLitigationToolStripMenuItem,
            this.aAFMigratedToolStripMenuItem,
            this.aPLFromRiskToolStripMenuItem,
            this.dailyGLToolStripMenuItem,
            this.faMSPastDueAccountToolStripMenuItem});
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(29, 25);
            this.toolStripButton2.Text = "Adjustment / Correction";
            this.toolStripButton2.ToolTipText = "Adjustment / Correction";
            // 
            // accountUnderLitigationToolStripMenuItem
            // 
            this.accountUnderLitigationToolStripMenuItem.Name = "accountUnderLitigationToolStripMenuItem";
            this.accountUnderLitigationToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.accountUnderLitigationToolStripMenuItem.Text = "Account Under Litigation";
            this.accountUnderLitigationToolStripMenuItem.Click += new System.EventHandler(this.accountUnderLitigationToolStripMenuItem_Click);
            // 
            // aAFMigratedToolStripMenuItem
            // 
            this.aAFMigratedToolStripMenuItem.Name = "aAFMigratedToolStripMenuItem";
            this.aAFMigratedToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.aAFMigratedToolStripMenuItem.Text = "AAF Migrated Account";
            // 
            // aPLFromRiskToolStripMenuItem
            // 
            this.aPLFromRiskToolStripMenuItem.Name = "aPLFromRiskToolStripMenuItem";
            this.aPLFromRiskToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.aPLFromRiskToolStripMenuItem.Text = "APL From Risk";
            // 
            // dailyGLToolStripMenuItem
            // 
            this.dailyGLToolStripMenuItem.Name = "dailyGLToolStripMenuItem";
            this.dailyGLToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.dailyGLToolStripMenuItem.Text = "Daily GL";
            // 
            // faMSPastDueAccountToolStripMenuItem
            // 
            this.faMSPastDueAccountToolStripMenuItem.Name = "faMSPastDueAccountToolStripMenuItem";
            this.faMSPastDueAccountToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.faMSPastDueAccountToolStripMenuItem.Text = "FaMS Past Due Account";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToExcelToolStripMenuItem});
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(29, 25);
            this.toolStripButton3.Text = "Export To Excel";
            // 
            // exportToExcelToolStripMenuItem
            // 
            this.exportToExcelToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nTCConsolidatorToolStripMenuItem,
            this.exchangeRateToolStripMenuItem,
            this.migratedAccountToolStripMenuItem,
            this.qualifyingCapitalToolStripMenuItem,
            this.accountUnderLitigationToolStripMenuItem1,
            this.correspondingGLToolStripMenuItem});
            this.exportToExcelToolStripMenuItem.Name = "exportToExcelToolStripMenuItem";
            this.exportToExcelToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.exportToExcelToolStripMenuItem.Text = "Export To Excel";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.qualifyingTableToolStripMenuItem,
            this.uSDollarExchangeRateToolStripMenuItem,
            this.gLCodeAndDescriptionToolStripMenuItem,
            this.setRawFilePathToolStripMenuItem});
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(29, 25);
            this.toolStripButton4.Text = "Maintenace";
            this.toolStripButton4.ToolTipText = "Maintenance";
            // 
            // qualifyingTableToolStripMenuItem
            // 
            this.qualifyingTableToolStripMenuItem.Name = "qualifyingTableToolStripMenuItem";
            this.qualifyingTableToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.qualifyingTableToolStripMenuItem.Text = "Qualifying Table";
            this.qualifyingTableToolStripMenuItem.Click += new System.EventHandler(this.qualifyingTableToolStripMenuItem_Click);
            // 
            // uSDollarExchangeRateToolStripMenuItem
            // 
            this.uSDollarExchangeRateToolStripMenuItem.Name = "uSDollarExchangeRateToolStripMenuItem";
            this.uSDollarExchangeRateToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.uSDollarExchangeRateToolStripMenuItem.Text = "US Dollar Exchange Rate";
            this.uSDollarExchangeRateToolStripMenuItem.Click += new System.EventHandler(this.uSDollarExchangeRateToolStripMenuItem_Click);
            // 
            // gLCodeAndDescriptionToolStripMenuItem
            // 
            this.gLCodeAndDescriptionToolStripMenuItem.Name = "gLCodeAndDescriptionToolStripMenuItem";
            this.gLCodeAndDescriptionToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.gLCodeAndDescriptionToolStripMenuItem.Text = "GL Code and Description";
            this.gLCodeAndDescriptionToolStripMenuItem.Click += new System.EventHandler(this.gLCodeAndDescriptionToolStripMenuItem_Click);
            // 
            // setRawFilePathToolStripMenuItem
            // 
            this.setRawFilePathToolStripMenuItem.Name = "setRawFilePathToolStripMenuItem";
            this.setRawFilePathToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.setRawFilePathToolStripMenuItem.Text = "Set Raw File Path";
            this.setRawFilePathToolStripMenuItem.Click += new System.EventHandler(this.setRawFilePathToolStripMenuItem_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 25);
            this.toolStripButton1.Text = "ttReports";
            this.toolStripButton1.ToolTipText = "Exceptional Reports";
            // 
            // panel3
            // 
            this.panel3.Location = new System.Drawing.Point(23, 109);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(489, 5);
            this.panel3.TabIndex = 52;
            // 
            // nTCConsolidatorToolStripMenuItem
            // 
            this.nTCConsolidatorToolStripMenuItem.Name = "nTCConsolidatorToolStripMenuItem";
            this.nTCConsolidatorToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.nTCConsolidatorToolStripMenuItem.Text = "NTC Consolidator";
            this.nTCConsolidatorToolStripMenuItem.Click += new System.EventHandler(this.nTCConsolidatorToolStripMenuItem_Click);
            // 
            // exchangeRateToolStripMenuItem
            // 
            this.exchangeRateToolStripMenuItem.Name = "exchangeRateToolStripMenuItem";
            this.exchangeRateToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.exchangeRateToolStripMenuItem.Text = "Exchange Rate";
            // 
            // migratedAccountToolStripMenuItem
            // 
            this.migratedAccountToolStripMenuItem.Name = "migratedAccountToolStripMenuItem";
            this.migratedAccountToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.migratedAccountToolStripMenuItem.Text = "Migrated Account";
            // 
            // qualifyingCapitalToolStripMenuItem
            // 
            this.qualifyingCapitalToolStripMenuItem.Name = "qualifyingCapitalToolStripMenuItem";
            this.qualifyingCapitalToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.qualifyingCapitalToolStripMenuItem.Text = "Qualifying Capital";
            // 
            // accountUnderLitigationToolStripMenuItem1
            // 
            this.accountUnderLitigationToolStripMenuItem1.Name = "accountUnderLitigationToolStripMenuItem1";
            this.accountUnderLitigationToolStripMenuItem1.Size = new System.Drawing.Size(191, 22);
            this.accountUnderLitigationToolStripMenuItem1.Text = "Account Under Litigation";
            // 
            // correspondingGLToolStripMenuItem
            // 
            this.correspondingGLToolStripMenuItem.Name = "correspondingGLToolStripMenuItem";
            this.correspondingGLToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.correspondingGLToolStripMenuItem.Text = "Corresponding GL";
            // 
            // frmConsolidator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1198, 613);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlWaitInfo);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblBusy);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnGenerate);
            this.MaximizeBox = false;
            this.Name = "frmConsolidator";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "NTC Consolidator";
            this.Load += new System.EventHandler(this.frmConsolidator_Load);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvConsolidator)).EndInit();
            this.pnlWaitInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ConsoMenu.ResumeLayout(false);
            this.ConsoMenu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroButton btnGenerate;
        private MetroFramework.Controls.MetroButton btnSearch;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroGrid dgvConsolidator;
        private MetroFramework.Controls.MetroTextBox txtSearch;
        private MetroFramework.Controls.MetroLabel lblBusy;
        private MetroFramework.Controls.MetroButton btnCancel;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Panel pnlWaitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroLabel lblWaitInfo;
        private MetroFramework.Controls.MetroLabel lblWaitStatus;
        private MetroFramework.Controls.MetroLabel lblWaitFilePath;
        private MetroFramework.Controls.MetroLabel lblWaitStatus1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip ConsoMenu;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem accountUnderLitigationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aAFMigratedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aPLFromRiskToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dailyGLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem faMSPastDueAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton3;
        private System.Windows.Forms.ToolStripMenuItem exportToExcelToolStripMenuItem;
        private System.Windows.Forms.ToolStripDropDownButton toolStripButton4;
        private System.Windows.Forms.ToolStripMenuItem qualifyingTableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSDollarExchangeRateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gLCodeAndDescriptionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setRawFilePathToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem nTCConsolidatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exchangeRateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem migratedAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qualifyingCapitalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountUnderLitigationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem correspondingGLToolStripMenuItem;
    }
}