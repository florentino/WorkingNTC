﻿using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmMigratedAccount : MetroFramework.Forms.MetroForm
    {
        private static frmMigratedAccount frmmigratedAccount = null;
        private IMigratedAccount migratedAccountRepository;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtmigratedAccount;
        DataTable dtRecords;
        DataTable dtAaf;
        string[] progressArray = new string[5];

        public static frmMigratedAccount Instance()
        {
            if (frmmigratedAccount == null)
            {
                frmmigratedAccount = new frmMigratedAccount();
            }
            return frmmigratedAccount;
        }
        
        public frmMigratedAccount()
        {
            InitializeComponent();
            this.migratedAccountRepository = new MigratedAccountRepository(new NTC_Context_Entities());
        }

        private void frmMigratedAccount_Load(object sender, EventArgs e)
        {

        }

        private DataTable AAFDataTable()
        {
            dtAaf = new DataTable("AAFDATA");

            dtAaf.Columns.Add("system");
            dtAaf.Columns.Add("accountno");
            dtAaf.Columns.Add("udibalance");
            dtAaf.Columns.Add("pvrv");
            dtAaf.Columns.Add("pvgd");

            //var startRow = 0;
            //DataRow dr = null;
            //foreach (DataRow row in dtunderLitigation.Rows)
            //{
            //    dr = dtAaf.NewRow();

            //    dr["system"] = "AAF";
            //    dr["accountno"] = dtunderLitigation.Rows[startRow]["accountno"].ToString();
            //}


            return dtAaf;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {

        }
    }
}
