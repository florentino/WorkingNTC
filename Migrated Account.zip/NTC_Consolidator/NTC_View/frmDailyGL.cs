﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmDailyGL : MetroFramework.Forms.MetroForm
    {

        private IDailyGL dailyGLRepository;
        private static frmDailyGL frmdailyGL = null;

        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtDailyGL;

        //DataTable dtupdated = new DataTable("Updated");
        NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];


        public static frmDailyGL Instance()
        {
            if (frmdailyGL == null)
            {
                frmdailyGL = new frmDailyGL();
            }
            return frmdailyGL;
        }

        public frmDailyGL()
        {
            InitializeComponent();
            this.dailyGLRepository = new DailyGLRepository(new NTC_Context_Entities());
            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            lblBusy.Text = "";
        }

        private void frmDailyGL_Load(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Fetching Data from server, Please wait...";
            lblWaitStatus.Text = "Status: Processing...";

            pnlWaitInfo.Visible = true;

            retrieveWorker = new BackgroundWorker();
            retrieveWorker.WorkerReportsProgress = true;
            retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
            retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
            retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
            retrieveWorker.WorkerSupportsCancellation = true;
            retrieveWorker.RunWorkerAsync();
        }

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Fetching Data from server, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                lblInfo.Text = "Total Records: " + dtDailyGL.Rows.Count.ToString();

                pnlWaitInfo.Visible = false;
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                //progressArray[0] = (1 * 100 / dtDailyGL.Rows.Count).ToString(); // percent
                //progressArray[1] = "Loading records, Please wait..."; //header text
                //progressArray[2] = "Status: In-progress"; //Status
                //progressArray[3] = "";// i.ToString(); //column
                //progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                var data = dailyGLRepository.GetAll();

                retrieveWorker.ReportProgress(1 * 100 / dtDailyGL.Rows.Count, progressArray); // wla lng, just to show the loading information
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while retrieving the records, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                throw new Exception("Error encountered while retrieving the records, Please contact your system administrator");
            }

        }

        private void table()
        {
            dtDailyGL.Columns.Add("GMACT");
            dtDailyGL.Columns.Add("GMCURC");
            dtDailyGL.Columns.Add("GMCNTR");
            dtDailyGL.Columns.Add("GMNAME");
            dtDailyGL.Columns.Add("GMCBAL");
            dtDailyGL.Columns.Add("GMFCYE");
            dtDailyGL.Columns.Add("GMEMO");
            dtDailyGL.Columns.Add("GFEMO");
            dtDailyGL.Columns.Add("GMYBAL");
            dtDailyGL.Columns.Add("GMFCYY");
        }
    }
}
