﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPastDue : MetroFramework.Forms.MetroForm
    {
        private static frmPastDue frmpastDue = null;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtPastDueAccount;
        string pastDueAccountFileName = "";
        NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];

        private IPastDueAccount pastDueAccountRepository;

        public static frmPastDue Instance()
        {
            if (frmpastDue == null)
            {
                frmpastDue = new frmPastDue();
            }
            return frmpastDue;
        }


        public frmPastDue()
        {
            InitializeComponent();
            this.pastDueAccountRepository = new PastDueAccountRepository(new NTC_Context_Entities());

            pnlWaitInfo.Location = new Point(
           this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            //  pnlSummary.Location = new Point(
            // this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
            // this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            //  pnlSummary.Visible = false;

            //  pnlInsertUpdate.Location = new Point(
            //this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
            //this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            //  pnlInsertUpdate.Visible = false;
            lblBusy.Text = "";

        }

        private void frmPastDue_Load(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        #region Retrieving records
        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                //if (_InValidDate)
                //{
                //    MetroMessageBox.Show(this, "\r\nInvalid date was detected by the system, Please check all the date format.", "Invalid Date", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
                //else
                //{
                //    MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //}
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                pastDueAccountFileName = Path.GetFileName(txtFilePath.Text);

                dtPastDueAccount.DefaultView.RowFilter = "SYSTEM = 'FAMS' AND statuspersystem = 'PAST DUE'";
                DataView dv = dtPastDueAccount.DefaultView;
                dv.Sort = "accountno asc";
                DataTable sortedDT = dv.ToTable();

                dgvPastDueAccount.DataSource = sortedDT;

                lblInfo.Text = "Total Records: " + dtPastDueAccount.Rows.Count.ToString();

                pnlWaitInfo.Visible = false;

                //btnExecute.Enabled = dtFromNTCRecords.Rows.Count > 0 ? true : false;


            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    // connString = string.Format("Provider = Microsoft.ACE.OLEDB.12.0;Data Source={0};" + "Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1;'", txtFilePath.Text);

                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                // string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();


                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE [F1] <> ''", conn);


                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);
                    progressArray[0] = (1 * 100 / dtold.Rows.Count).ToString(); // percent
                    progressArray[1] = "Loading records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    retrieveWorker.ReportProgress(1 * 100 / dtold.Rows.Count, progressArray); // wla lng, just to show the loading information

                    foreach (DataColumn dc in dtold.Columns)
                    {
                        var name = dtold.Rows[0][dc].ToString().ToLower();
                        var newname = Regex.Replace(name, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToUpper();
                        dc.ColumnName = newname;
                    }

                    //var NewHeader = Regex.Replace(headercolumn, @"([^a-zA-Z0-9]|^\s)", string.Empty).ToLower();

                    //dtIcbs.Columns.Add(NewHeader);

                    dtold.Rows.RemoveAt(0);

                    dtPastDueAccount = dtold;

                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else if (ex.Message.Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }

        #endregion

        #region Save PastDue
        private void btnExecute_Click(object sender, EventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Saving records, Please wait...";
            lblWaitStatus.Text = "Status: In-progress...";

            //Get Date
            dateparam = pastDueAccountRepository.GetDate();

            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();
        }

        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var iCount = 1;
                foreach (DataRow dritem in dtPastDueAccount.Rows)
                {
                    BDOLF_Consolidator data = new BDOLF_Consolidator();

                    // var _System = dritem["SYSTEM"].ToString();

                    if (dritem["SYSTEM"].ToString().Trim() == "FAMS" && dritem["STATUSPERSYSTEM"].ToString().Trim() == "PAST DUE")
                    {
                        #region Data
                        progressArray[0] = (iCount * 100 / dtPastDueAccount.Rows.Count).ToString(); // percent
                        progressArray[1] = "Saving records, Please wait..."; //header text
                        progressArray[2] = "Status: In-progress"; //Status
                        progressArray[3] = "";// i.ToString(); //column
                        progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                        data.RawFiles = pastDueAccountFileName.ToString();
                        data.isConsolidated = true;
                        data.isDeleted = false;
                        data.UserName = frmConsolidator.UserName;
                        data.TransDate = DateTime.Today;
                        data.RecordDate = dateparam; // Convert.ToDateTime(dritem["VALUEDATE"] == null ? "" : dritem["VALUEDATE"]);
                        data.SYSTEM = dritem["SYSTEM"] == null ? "" : dritem["SYSTEM"].ToString();
                        data.AccountNo = dritem["ACCOUNTNO"] == null ? "" : dritem["ACCOUNTNO"].ToString();
                        data.ClientName = dritem["CLIENTNAME"] == null ? "" : dritem["CLIENTNAME"].ToString();
                        data.AO = dritem["AO"] == null ? "" : dritem["AO"].ToString();
                        data.FacilityCode = dritem["FACILITYCODE"] == null ? "" : dritem["FACILITYCODE"].ToString();
                        data.StatusPerSystem = dritem["STATUSPERSYSTEM"] == null ? "" : dritem["STATUSPERSYSTEM"].ToString();
                        data.ValueDate = Convert.ToDateTime(dritem["VALUEDATE"] == null ? "01/01/1900" : dritem["VALUEDATE"]);
                        data.FirstDueDate = Convert.ToDateTime(dritem["FIRSTDUEDATE"] == null ? "" : dritem["FIRSTDUEDATE"]);
                        data.MaturityDate = Convert.ToDateTime(dritem["MATURITYDATE"] == null ? "" : dritem["MATURITYDATE"]);
                        data.TotalLoan = Convert.ToDecimal(dritem["TOTALLOAN"] == null ? "" : dritem["TOTALLOAN"]);
                        data.OB = Convert.ToDecimal(dritem["OB"] == null ? "" : dritem["OB"]);
                        data.MonthlyOB = Convert.ToDecimal(dritem["MONTHLYOB"] == null ? "" : dritem["MONTHLYOB"]);
                        data.UDIBalance = Convert.ToDecimal(dritem["UDIBALANCE"] == null ? "" : dritem["UDIBALANCE"]);
                        data.ClientsEquity = Convert.ToDecimal(dritem["CLIENTSEQUITY"] == null ? "" : dritem["CLIENTSEQUITY"]);
                        data.AccruedInterestReceivable = Convert.ToDecimal(dritem["ACCRUEDINTERESTRECEIVABLE"] == null ? "" : dritem["ACCRUEDINTERESTRECEIVABLE"]);
                        data.OrigERV = Convert.ToDecimal(dritem["ORIGERV"] == null ? "" : dritem["ORIGERV"]);
                        data.PVRV = Convert.ToDecimal(dritem["PVRV"] == null ? "" : dritem["PVRV"]);
                        data.OrigGD = Convert.ToDecimal(dritem["ORIGGD"] == null ? "" : dritem["ORIGGD"]);
                        data.PVGD = Convert.ToDecimal(dritem["PVGD"] == null ? "" : dritem["PVGD"]);
                        data.TotalLoanPortfolio = Convert.ToDecimal(dritem["TOTALLOANPORTFOLIO"] == null ? "" : dritem["TOTALLOANPORTFOLIO"]);
                        data.NTC = dritem["NTC"] == null ? "" : dritem["NTC"].ToString();
                        data.OriginalRate = Convert.ToDecimal(dritem["ORIGINALRATE"] == null ? "" : dritem["ORIGINALRATE"]);
                        data.CurrentRate = Convert.ToDecimal(dritem["CURRENTRATE"] == null ? "" : dritem["CURRENTRATE"]);
                        data.TermInMonths = Convert.ToInt32(dritem["TERMINMONTHS"] == null ? "" : dritem["TERMINMONTHS"]);
                        data.RemainingTermInMonths = Convert.ToInt32(dritem["REMAININGTERMINMONTHS"] == null ? "" : dritem["REMAININGTERMINMONTHS"]);
                        data.OriginalAmortizationAAF = Convert.ToDecimal(dritem["ORIGINALAMORTIZATIONAAF"] == null ? "" : dritem["ORIGINALAMORTIZATIONAAF"]);
                        data.PaymentScheduleAmortizationAAF = Convert.ToDecimal(dritem["PAYMENTSCHEDULEAMORTIZATIONAAF"] == null ? "" : dritem["PAYMENTSCHEDULEAMORTIZATIONAAF"]);
                        data.RepricedDate = Convert.ToDateTime(dritem["REPRICEDDATE"] == null ? "" : dritem["REPRICEDDATE"]);
                        data.AAFICBSRateType = dritem["AAFICBSRATETYPE"] == null ? "" : dritem["AAFICBSRATETYPE"].ToString();
                        data.RepricedAmortization = Convert.ToDecimal(dritem["REPRICEDAMORTIZATION"] == null ? "" : dritem["REPRICEDAMORTIZATION"]);
                        data.PastDueDateITLDateExtractedPerAAFICBS = dritem["PASTDUEDATEITLDATEEXTRACTEDPERAAFICBS"].ToString();
                        data.PerFaMSAAFICBSIndustryCode = dritem["PERFAMSAAFICBSINDUSTRYCODE"] == null ? "" : dritem["PERFAMSAAFICBSINDUSTRYCODE"].ToString();
                        data.IndustryHeader = dritem["INDUSTRYHEADER"] == null ? "" : dritem["INDUSTRYHEADER"].ToString();
                        data.IndustryDetail = dritem["INDUSTRYDETAIL"] == null ? "" : dritem["INDUSTRYDETAIL"].ToString();
                        data.Collateral = dritem["COLLATERAL"] == null ? "" : dritem["COLLATERAL"].ToString();
                        data.PerFaMSAAFICBSAssetSize = dritem["PERFAMSAAFICBSASSETSIZE"] == null ? "" : dritem["PERFAMSAAFICBSASSETSIZE"].ToString();
                        data.PerFaMSAAFICBSAssetSizeInWords = dritem["PERFAMSAAFICBSASSETSIZEINWORDS"] == null ? "" : dritem["PERFAMSAAFICBSASSETSIZEINWORDS"].ToString();
                        data.ICBSGLCode = dritem["ICBSGLCODE"] == null ? "" : dritem["ICBSGLCODE"].ToString();
                        data.ICBSGLName = dritem["ICBSGLNAME"] == null ? "" : dritem["ICBSGLNAME"].ToString();
                        data.CostCenter = dritem["COSTCENTER"] == null ? "" : dritem["COSTCENTER"].ToString();
                        data.BranchNameOfCostCenterPerSystem = dritem["BRANCHNAMEOFCOSTCENTERPERSYSTEM"] == null ? "" : dritem["BRANCHNAMEOFCOSTCENTERPERSYSTEM"].ToString();
                        data.StatusPerGL = dritem["STATUSPERGL"] == null ? "" : dritem["STATUSPERGL"].ToString();
                        data.OriginatingBranchBooked = dritem["ORIGINATINGBRANCHBOOKED"] == null ? "" : dritem["ORIGINATINGBRANCHBOOKED"].ToString();
                        data.NationalityPerICBS = dritem["NATIONALITYPERICBS"] == null ? "" : dritem["NATIONALITYPERICBS"].ToString();
                        data.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"] == null ? "" : dritem["NEXTRATEREVIEWDATEEXTRACTEDPERFAMSAAFICBS"]);
                        data.TaxID = dritem["TAXID"] == null ? "" : dritem["TAXID"].ToString();
                        data.LoanPurposeCode = dritem["LOANPURPOSECODE"] == null ? "" : dritem["LOANPURPOSECODE"].ToString();
                        data.MaturityTypeCode = dritem["MATURITYTYPECODE"] == null ? "" : dritem["MATURITYTYPECODE"].ToString();
                        data.BankRelationship = dritem["BANKRELATIONSHIP"] == null ? "" : dritem["BANKRELATIONSHIP"].ToString();
                        data.SyndicatedLoanInd = dritem["SYNDICATEDLOANIND"] == null ? "" : dritem["SYNDICATEDLOANIND"].ToString();
                        data.CustomerTypeDescription = dritem["CUSTOMERTYPEDESCRIPTION"] == null ? "" : dritem["CUSTOMERTYPEDESCRIPTION"].ToString();
                        data.RELCode = dritem["RELCODE"] == null ? "" : dritem["RELCODE"].ToString();
                        data.REECode = dritem["REECODE"] == null ? "" : dritem["REECODE"].ToString();
                        data.REEAddtlInfo = dritem["REEADDTLINFO"] == null ? "" : dritem["REEADDTLINFO"].ToString();
                        data.AcctRef = dritem["ACCTREF"] == null ? "" : dritem["ACCTREF"].ToString();
                        data.RPT = dritem["RPT"] == null ? "" : dritem["RPT"].ToString();
                        data.ASSETCOST = Convert.ToDecimal(dritem["ASSETCOST"] == null ? "" : dritem["ASSETCOST"]);
                        data.LeaseType = dritem["LEASETYPE"] == null ? "" : dritem["LEASETYPE"].ToString();
                        data.Provisioning = dritem["PROVISIONING"] == null ? "" : dritem["PROVISIONING"].ToString();
                        data.Matrix = dritem["MATRIX"] == null ? "" : dritem["MATRIX"].ToString();
                        data.Remarks = dritem["REMARKS"] == null ? "" : dritem["REMARKS"].ToString();
                        data.ICBSCollateralCode = dritem["ICBSCOLLATERALCODE"] == null ? "" : dritem["ICBSCOLLATERALCODE"].ToString();
                        data.AssetValue = Convert.ToDecimal(dritem["ASSETVALUE"] == null ? "" : dritem["ASSETVALUE"]);
                        data.ApprovedAmount = Convert.ToDecimal(dritem["APPROVEDAMOUNT"] == null ? "" : dritem["APPROVEDAMOUNT"]);
                        data.CPNumber = dritem["CPNUMBER"] == null ? "" : dritem["CPNUMBER"].ToString();
                        data.LastInterestPay = Convert.ToDecimal(dritem["LASTPRINCIPALPAY"] == null ? "" : dritem["LASTPRINCIPALPAY"]);
                        data.PrincipalPayDate = Convert.ToDateTime(dritem["PRINCIPALPAYDATE"] == null ? "" : dritem["PRINCIPALPAYDATE"]);
                        data.LastInterestPay = Convert.ToDecimal(dritem["LASTINTERESTPAY"] == null ? "" : dritem["LASTINTERESTPAY"]);
                        data.LastInterestPayDate = Convert.ToDateTime("01/01/1900");
                        data.PreviousMonthsNPLTaggingByRisk = "";
                        data.SpecificRequiredProvisions = "";
                        data.GeneralRequiredProvisions = "";
                        data.Reason = "";
                        #endregion

                        pastDueAccountRepository.InsertRecord(data);

                        saveWorker.ReportProgress(iCount++ * 100 / dtPastDueAccount.Rows.Count, progressArray); // wla lng
                    }
                }
            }
            catch (Exception ex)
            {

                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";

                MetroMessageBox.Show(this, "\r\nPast Due Account was successfully appended.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }
        #endregion
    }
}
