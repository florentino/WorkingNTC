﻿using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Repository
{
    public class DailyGLRepository : IDailyGL, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public DailyGLRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public IEnumerable<BDOLF_Consolidator> GetAll()
        {
            var parameter = DateTime.Today;

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
             var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable();
           // var query = from data in context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable()
            //group data by new { data.AccountNo, data.ICBSGLName } into n
            //select new { n.Key.AccountNo, n.Key.ICBSGLName };
            return query;
        }

        public DateTime GetDate()
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            try
            {
                context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        System.Console.WriteLine("Property: {0} Error: {1}", validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
            }
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        

    }
}