﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IPastDueAccount
    {
        IEnumerable<BDOLF_Consolidator> GetAll();
        BDOLF_Consolidator GetByAccountNo(int AccountNo);
        BDOLF_Consolidator GetByAccountNo(string AccountNo);
        void InsertRecord(BDOLF_Consolidator pastDueData);
        void UpdateConsolidator(BDOLF_Consolidator pastDueData);
        bool AccountNotExists(string AccountNo, string System);
        DateTime GetDate();
        void Save();
    }
}
