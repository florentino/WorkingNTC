﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    interface IQualifyingCapital : IDisposable
    {

        IEnumerable<BDOLF_QualifyingCapital> GetAll();
        BDOLF_QualifyingCapital GetByID(int QID);
        BDOLF_QualifyingCapital GetByCode(string QDate);
        void InsertQCapital(BDOLF_QualifyingCapital QCapital);
        void DeleteQCapital(int QID);
        void TruncateTable();
        void DeleteQCapital(string QDate);
        void UpdateQCapital(BDOLF_QualifyingCapital QCapital);
        void Save();
    }
}
