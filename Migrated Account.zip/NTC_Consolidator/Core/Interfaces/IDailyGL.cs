﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
   public interface IDailyGL
    {
        IEnumerable<BDOLF_Consolidator> GetAll();
        DateTime GetDate();
        void Save();
    }
}
