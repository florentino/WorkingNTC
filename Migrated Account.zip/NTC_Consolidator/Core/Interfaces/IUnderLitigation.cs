﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IUnderLitigation : IDisposable
    {
        IEnumerable<BDOLF_Consolidator> GetAll();
        BDOLF_Consolidator GetByAccountNo(int AccountNo);
        BDOLF_Consolidator GetByAccountNo(string AccountNo);
        void InsertRecord(BDOLF_Consolidator litigation);
        void UpdateConsolidator(BDOLF_Consolidator litigation);
        void DeleteConsolidator(BDOLF_Consolidator litigation);
        bool AccountNotExists(string AccountNo, string keyword);
        void Save();
    }
}
