﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmUnderLitigation : MetroFramework.Forms.MetroForm
    {
        private static frmUnderLitigation litigationform = null;
        private IUnderLitigation underLitigationRepository;
        private string _underLitigation = "";
        string underLitigationFileName = "";
        private string _underLitigationEXT = "";
        private string _underLitigationDateParameter = "";
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtunderLitigation;
        DataTable dtRecords = new DataTable();
        public static frmUnderLitigation Instance()
        {
            if (litigationform == null)
            {
                litigationform = new frmUnderLitigation();
            }
            return litigationform;
        }


        public frmUnderLitigation()
        {
            InitializeComponent();
            this.underLitigationRepository = new UnderLitigationRepository(new NTC_Context_Entities());
            lblBusy.Text = "";

            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls| Excel Files(.xlsx) | *.xlsx";


            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;
                lblWaitInfo.Text = "Please wait, While loading excel file.";
                lblWaitStatus.Text = "Status: Processing...";
                dtunderLitigation = new DataTable();
                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }

           
            pnlWaitInfo.Visible = false;
        }

        private void frmUnderLitigation_Load(object sender, EventArgs e)
        {

        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";

           
            //qualifyingCapitalRepository.GetAll(); 

            dtunderLitigation = (this.dgvAccountUnderLit.DataSource as DataTable).Copy();
            lblWaitInfo.Text = "Initializing, Please wait...";
            lblWaitStatus.Text = "Status: Initializing...";
            lblBusy.Text = "";
            lblWaitStatus.Text = string.Format("Status: Completed");

            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();

        }

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";
            lblWaitStatus.Text = string.Format("Status: In-progress...");
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                dgvAccountUnderLit.DataSource = dtunderLitigation;
                dgvAccountUnderLit.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

                lblInfo.Text = "Total Records: " + dtunderLitigation.Rows.Count.ToString();
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                underLitigationFileName = Path.GetFileName(txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [" + worksheetname + "]", conn);

                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);


                    //Convert Row 3 value as a header of the DataTable
                    foreach (DataColumn dc in dtold.Columns)
                    {
                        dc.ColumnName = dtold.Rows[3][dc].ToString();
                    }

                    DataView view = new System.Data.DataView(dtold);
                    DataTable selected = view.ToTable("Selected", false, "GLCode", "GLDesc");

                    // _underLitigationDateParameter = Convert.ToDateTime(dtold.Rows[1][1].ToString()).ToShortDateString().ToString();

                    IEnumerable<DataRow> erc = selected.AsEnumerable().Skip(4);
                    dtold = new DataTable();
                    dtold = erc.CopyToDataTable();


                    var iCount = 0;
                   
                    dtunderLitigation.Columns.Add("GLCode");
                    dtunderLitigation.Columns.Add("GLDesc");
                    DataRow dr = null;
                    foreach (var item in dtold.Rows)
                    {
                        if (!string.IsNullOrEmpty(dtold.Rows[iCount]["GLCode"].ToString()))
                        {
                            dr = dtunderLitigation.NewRow();
                            dr["GLCode"] = dtold.Rows[iCount]["GLCode"].ToString();
                            dr["GLDesc"] = dtold.Rows[iCount]["GLDesc"].ToString();

                            dtunderLitigation.Rows.Add(dr);
                            iCount++;
                        }
                    }


                }
                //dtRecords = dtunderLitigation;
                retrieveWorker.ReportProgress(0); // wla lng

            }
            catch (Exception ex)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //MetroMessageBox.Show(new Form() { TopMost = true }, "\r\nFaMS RAW File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else
                {
                    //oledbConn.Close();
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //MetroMessageBox.Show(new Form() { TopMost = true }, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lblWaitInfo.Text = "Inserting records to DataBase, Please wait...";
            lblWaitStatus.Text = "Status: Processing...";
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";
                MetroMessageBox.Show(this, "\r\nData was successfully added.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                foreach (DataRow dritem in dtunderLitigation.Rows)
                {
                    var _code = dritem["GLCode"].ToString();
                    var _desc = dritem["GLDesc"].ToString();

                    if (underLitigationRepository.AccountNotExists(_code))
                    {
                        underLitigationRepository.UpdateConsolidator(_code, _desc);
                    }
                }



                retrieveWorker.ReportProgress(0); // wla lng

            }
            catch (Exception ex)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";

                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //MetroMessageBox.Show(new Form() { TopMost = true }, "\r\nFaMS RAW File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else
                {
                    //oledbConn.Close();
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //MetroMessageBox.Show(new Form() { TopMost = true }, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }


    }
}
