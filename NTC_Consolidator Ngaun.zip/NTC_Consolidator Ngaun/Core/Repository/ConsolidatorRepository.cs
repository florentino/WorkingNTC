﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using NTC_Consolidator.NTC_Model;
using System.Transactions;

namespace NTC_Consolidator.Core.Repository
{
    public class ConsolidatorRepository : IConsolidator, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public ConsolidatorRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public void BulkDelete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object[] objdata)
        {
            try
            {
                var icbsData = (DataTable)objdata[0];
                var aafData = (DataTable)objdata[1];
                var famsData = (DataTable)objdata[2];

                using (TransactionScope scope = new TransactionScope())
                {
                    NTC_Context_Entities context = null;
                    try
                    {
                        context = new NTC_Context_Entities();
                        context.Configuration.AutoDetectChangesEnabled = false;
                       // context.Configuration.ValidateOnSaveEnabled = false;
                        context.Database.CommandTimeout = 2500;
                        int count = 0;
                        int icbscount = 0;

                        //BDOLF_Consolidator itemdata = new BDOLF_Consolidator();
                       // AAFModel item = new AAFModel();
                        #region ICBS

                        foreach (DataRow entityToInsert in icbsData.Rows)
                        {
                            BDOLF_Consolidator item = new BDOLF_Consolidator();
                            item.AccountNo = entityToInsert["AccountNo"].ToString();//.ItemArray[0].ToString();
                            item.ClientName = entityToInsert["ClientName"].ToString();//.ItemArray[1].ToString();
                            item.AO = entityToInsert["AO"].ToString();//.ItemArray[2].ToString();
                            item.FacilityCode = entityToInsert["FacilityCode"].ToString();//.ItemArray[3].ToString();
                            item.StatusPerSystem = entityToInsert["StatusPerSystem"].ToString();//.ItemArray[4].ToString();
                            item.ValueDate = entityToInsert["ValueDate"].ToString();//.ItemArray[5].ToString();
                            item.MaturityDate = entityToInsert["MaturityDate"].ToString();//.ItemArray[6].ToString();
                            item.TotalLoan = entityToInsert["TotalLoan"].ToString();//.ItemArray[7].ToString();
                            item.OB = entityToInsert["OB"].ToString();//.ItemArray[8].ToString();
                            item.MonthlyOB = entityToInsert["MonthlyOB"].ToString();//.ItemArray[9].ToString();
                            item.AccruedInterestReceivable = entityToInsert["AccruedInterestReceivable"].ToString();//.ItemArray[10].ToString();
                            item.OriginalRate = entityToInsert["OriginalRate"].ToString();//.ItemArray[11].ToString();
                            item.CurrentRate = entityToInsert["CurrentRate"].ToString();//.ItemArray[12].ToString();
                            item.TermInMonths = entityToInsert["TermInMonths"].ToString();//.ItemArray[13].ToString();
                            item.AAFICBSRateType = entityToInsert["AAFICBSRateType"].ToString();//.ItemArray[14].ToString();
                            item.PastDueDateITLDateExtractedPerAAFICBS = entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString();//.ItemArray[15].ToString();
                            item.PerFaMSAAFICBSIndustryCode = entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString();//.ItemArray[16].ToString();
                            item.IndustryHeader = entityToInsert["IndustryHeader"].ToString();//.ItemArray[17].ToString();
                            item.IndustryDetail = entityToInsert["IndustryDetail"].ToString();//.ItemArray[18].ToString();
                            item.Collateral = entityToInsert["Collateral"].ToString();//.ItemArray[19].ToString();
                            item.PerFaMSAAFICBSAssetSize = entityToInsert["PerFaMSAAFICBSAssetSize"].ToString();//.ItemArray[20].ToString();
                            item.CostCenter = entityToInsert["CostCenter"].ToString();//.ItemArray[21].ToString();
                            item.NationalityPerICBS = entityToInsert["NationalityPerICBS"].ToString();//.ItemArray[22].ToString();
                            item.NextRateReviewDateExtractedPerFaMSAAFICBS = entityToInsert["NextRateReviewDateExtractedPerFaMSAAFICBS"].ToString();//.ItemArray[23].ToString();
                            item.TaxID = entityToInsert["TaxID"].ToString();//.ItemArray[24].ToString();
                            item.LoanPurposeCode = entityToInsert["LoanPurposeCode"].ToString();//.ItemArray[25].ToString();
                            item.MaturityTypeCode = entityToInsert["MaturityTypeCode"].ToString();//.ItemArray[26].ToString();
                            item.BankRelationship = entityToInsert["BankRelationship"].ToString();//.ItemArray[27].ToString();
                            item.SyndicatedLoanInd = entityToInsert["SyndicatedLoanInd"].ToString();//.ItemArray[28].ToString();
                            item.CustomerTypeDescription = entityToInsert["CustomerTypeDescription"].ToString();//.ItemArray[29].ToString();
                            item.RPT = entityToInsert["RPT"].ToString();//.ItemArray[30].ToString();
                            item.ICBSCollateralCode = entityToInsert["ICBSCollateralCode"].ToString();//.ItemArray[31].ToString();
                            item.AssetValue = entityToInsert["AssetValue"].ToString();//.ItemArray[32].ToString();
                            item.ApprovedAmount = entityToInsert["ApprovedAmount"].ToString();//.ItemArray[33].ToString();
                            item.LastPrincipalPay = entityToInsert["LastPrincipalPay"].ToString();//.ItemArray[34].ToString();
                            item.PrincipalPayDate = entityToInsert["PrincipalPayDate"].ToString();//.ItemArray[35].ToString();
                            item.LastInterestPay = entityToInsert["LastInterestPay"].ToString();//.ItemArray[36].ToString();
                            item.LastInterestPayDate = entityToInsert["LastInterestPayDate"].ToString();//.ItemArray[37].ToString();
                            item.PreviousMonthsNPLTaggingByRisk = entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString();//.ItemArray[38].ToString();
                            item.SpecificRequiredProvisions = entityToInsert["SpecificRequiredProvisions"].ToString();//.ItemArray[39].ToString();
                            item.GeneralRequiredProvisions = entityToInsert["GeneralRequiredProvisions"].ToString();//.ItemArray[40].ToString();
                            item.Reason = entityToInsert["Reason"].ToString();//.ItemArray[41].ToString();
                            item.RawFiles = entityToInsert["RawFiles"].ToString();//"";
                            item.isConsolidated = Convert.ToBoolean(entityToInsert["isConsolidated"]);//true;
                            item.isDeleted = Convert.ToBoolean(entityToInsert["isDeleted"]);//false;
                            item.UserName = entityToInsert["UserName"].ToString();//"dong";
                            item.TransDate = entityToInsert["TransDate"].ToString();//DateTime.Now.ToString();
                            item.RecordDate = entityToInsert["RecordDate"].ToString();//DateTime.Now.ToString(); //Convert.ToDateTime(entityToInsert.ItemArray[7]);
                            item.SYSTEM = entityToInsert["SYSTEM"].ToString();//"icbs";// entityToInsert.ItemArray[8].ToString();
                            ++count;
                            ++icbscount;
                            context = AddToContext(context, item, count, 100, true);

                        }
                       
                        #endregion

                        #region AAF
                        //foreach (var entityToInsert in listaaf)
                        foreach (DataRow entityToInsert in aafData.Rows)
                        {
                             BDOLF_Consolidator item = new BDOLF_Consolidator();

                            // item.TransID = entityToInsert.ItemArray[0].ToString();

                            item.AccountNo = entityToInsert["AccountNo"].ToString();//.ItemArray[0].ToString();
                            item.ClientName = entityToInsert["ClientName"].ToString();//.ItemArray[1].ToString();
                            item.AO = entityToInsert["AO"].ToString();//.ItemArray[2].ToString();
                            item.FacilityCode = entityToInsert["FacilityCode"].ToString();//.ItemArray[3].ToString();
                            item.StatusPerSystem = entityToInsert["StatusPerSystem"].ToString();//.ItemArray[4].ToString();
                            item.ValueDate = entityToInsert["ValueDate"].ToString();//.ItemArray[5].ToString();
                            item.FirstDueDate = entityToInsert["FirstDueDate"].ToString();//.ItemArray[6].ToString();
                            item.MaturityDate = entityToInsert["MaturityDate"].ToString();//.ItemArray[6].ToString();
                            item.TotalLoan = entityToInsert["TotalLoan"].ToString();//.ItemArray[7].ToString();
                            item.OB = entityToInsert["OB"].ToString();//.ItemArray[8].ToString();
                            item.MonthlyOB = entityToInsert["MonthlyOB"].ToString();//.ItemArray[9].ToString();
                            item.UDIBalance = entityToInsert["UDIBalance"].ToString();//.ItemArray[11]);
                            item.OrigERV = entityToInsert["OrigERV"].ToString();//.ItemArray[13];
                            item.PVRV = entityToInsert["PVRV"].ToString();//.ItemArray[14];
                            item.OrigGD = entityToInsert["OrigGD"].ToString();//.ItemArray[15];
                            item.PVGD = entityToInsert["PVGD"].ToString();//.ItemArray[16];
                            item.OriginalRate = entityToInsert["OriginalRate"].ToString();//.ItemArray[11].ToString();
                            item.CurrentRate = entityToInsert["CurrentRate"].ToString();//.ItemArray[12].ToString();
                            item.TermInMonths = entityToInsert["TermInMonths"].ToString();//.ItemArray[13].ToString();
                            item.RemainingTermInMonths = entityToInsert["RemainingTermInMonths"].ToString();//.ItemArray[22].ToString();
                            item.OriginalAmortizationAAF = entityToInsert["OriginalAmortizationAAF"].ToString();//.ItemArray[23]);
                            item.PaymentScheduleAmortizationAAF = entityToInsert["PaymentScheduleAmortizationAAF"].ToString();//.ItemArray[24]);
                            item.RepricedDate = entityToInsert["RepricedDate"].ToString();//.ItemArray[25].ToString();
                            item.AAFICBSRateType = entityToInsert["AAFICBSRateType"].ToString();//.ItemArray[14].ToString();
                            item.RepricedAmortization = entityToInsert["RepricedAmortization"].ToString();//.ItemArray[27]);
                            item.PastDueDateITLDateExtractedPerAAFICBS = entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString();//.ItemArray[15].ToString();
                            item.PerFaMSAAFICBSIndustryCode = entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString();//.ItemArray[16].ToString();
                            item.IndustryHeader = entityToInsert["IndustryHeader"].ToString();//.ItemArray[17].ToString();
                            item.IndustryDetail = entityToInsert["IndustryDetail"].ToString();//.ItemArray[18].ToString();
                            item.Collateral = entityToInsert["Collateral"].ToString();//.ItemArray[19].ToString();
                            item.PerFaMSAAFICBSAssetSizeInWords = entityToInsert["PerFaMSAAFICBSAssetSizeInWords"].ToString();//.ItemArray[34].ToString();
                            item.ICBSGLCode = entityToInsert["ICBSGLCode"].ToString();//.ItemArray[35].ToString();
                            item.ICBSGLName = entityToInsert["ICBSGLName"].ToString();//.ItemArray[36].ToString();
                            item.CostCenter = entityToInsert["CostCenter"].ToString();//.ItemArray[21].ToString();
                            item.BranchNameOfCostCenterPerSystem = entityToInsert["BranchNameOfCostCenterPerSystem"].ToString();//.ItemArray[38].ToString();
                            item.OriginatingBranchBooked = entityToInsert["OriginatingBranchBooked"].ToString();//.ItemArray[40].ToString();
                            item.NationalityPerICBS = entityToInsert["NationalityPerICBS"].ToString();//.ItemArray[22].ToString();
                            item.NextRateReviewDateExtractedPerFaMSAAFICBS = entityToInsert["NextRateReviewDateExtractedPerFaMSAAFICBS"].ToString();//.ItemArray[23].ToString();
                            item.TaxID = entityToInsert["TaxID"].ToString();//.ItemArray[24].ToString();
                            item.CustomerTypeDescription = entityToInsert["CustomerTypeDescription"].ToString();//.ItemArray[29].ToString();
                            item.RELCode = entityToInsert["RELCode"].ToString();//.ItemArray[49].ToString();
                            item.REECode = entityToInsert["REECode"].ToString();//.ItemArray[50].ToString();
                            item.REEAddtlInfo = entityToInsert["REEAddtlInfo"].ToString();//.ItemArray[51].ToString();
                            item.AcctRef = entityToInsert["AcctRef"].ToString();//.ItemArray[52].ToString();
                            item.RPT = entityToInsert["RPT"].ToString();//.ItemArray[30].ToString();
                            item.ASSETCOST = entityToInsert["ASSETCOST"].ToString();//.ItemArray[54].ToString();
                            item.LeaseType = entityToInsert["LeaseType"].ToString();//.ItemArray[55].ToString();
                            item.ICBSCollateralCode = entityToInsert["ICBSCollateralCode"].ToString();//.ItemArray[31].ToString();
                            item.AssetValue = entityToInsert["AssetValue"].ToString();//.ItemArray[32].ToString();
                            item.ApprovedAmount = entityToInsert["ApprovedAmount"].ToString();//.ItemArray[33].ToString();
                            item.CPNumber = entityToInsert["CPNumber"].ToString();//.ItemArray[62].ToString();
                            item.LastPrincipalPay = entityToInsert["LastPrincipalPay"].ToString();//.ItemArray[34].ToString();
                            item.PrincipalPayDate = entityToInsert["PrincipalPayDate"].ToString();//.ItemArray[35].ToString();
                            item.LastInterestPay = entityToInsert["LastInterestPay"].ToString();//.ItemArray[36].ToString();
                            item.LastInterestPayDate = entityToInsert["LastInterestPayDate"].ToString();//.ItemArray[37].ToString();
                            item.PreviousMonthsNPLTaggingByRisk = entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString();//.ItemArray[38].ToString();
                            item.SpecificRequiredProvisions = entityToInsert["SpecificRequiredProvisions"].ToString();//.ItemArray[39].ToString();
                            item.GeneralRequiredProvisions = entityToInsert["GeneralRequiredProvisions"].ToString();//.ItemArray[40].ToString();
                            item.Reason = entityToInsert["Reason"].ToString();//.ItemArray[41].ToString();
                            item.RawFiles = entityToInsert["RawFiles"].ToString();
                            item.isConsolidated = Convert.ToBoolean(entityToInsert["isConsolidated"]);
                            item.isDeleted = Convert.ToBoolean(entityToInsert["isDeleted"]);
                            item.UserName = entityToInsert["UserName"].ToString();
                            item.TransDate = entityToInsert["TransDate"].ToString();
                            item.RecordDate = entityToInsert["RecordDate"].ToString();
                            item.SYSTEM = entityToInsert["SYSTEM"].ToString();
                            ++count;
                            context = AddToContext(context, item, count, 100, true);

                        }
                        
                        #endregion

                        #region FaMS

                        //foreach (var entityToInsert in listaaf)
                        Parallel.ForEach(famsData.AsEnumerable(), (dRow) =>
                        {
                            BDOLF_Consolidator item = new BDOLF_Consolidator();

                            item.SYSTEM = dRow["SYSTEM"].ToString();
                            item.RecordDate = dRow["RecordDate"].ToString();
                            item.Reason = dRow["Reason"].ToString();
                            item.RawFiles = dRow["RawFiles"].ToString();
                            item.isDeleted = Convert.ToBoolean(dRow["isDeleted"]);
                            item.UserName = dRow["UserName"].ToString();
                            item.TransDate = dRow["TransDate"].ToString();
                            item.isConsolidated = Convert.ToBoolean(dRow["isConsolidated"]);
                            item.AccountNo = dRow["AccountNo"].ToString();
                            item.ClientName = dRow["ClientName"].ToString();
                            item.AO = dRow["AO"].ToString();
                            item.StatusPerSystem = dRow["StatusPerSystem"].ToString();
                            item.ValueDate = dRow["ValueDate"].ToString();
                            item.MaturityDate = dRow["MaturityDate"].ToString();
                            item.TotalLoan = dRow["TotalLoan"].ToString();
                            item.OB = dRow["OB"].ToString();
                            item.MonthlyOB = dRow["MonthlyOB"].ToString();
                            item.OriginalRate = dRow["OriginalRate"].ToString();
                            item.CurrentRate = dRow["CurrentRate"].ToString();
                            item.TermInMonths = dRow["TermInMonths"].ToString();
                            item.PerFaMSAAFICBSIndustryCode = dRow["PerFaMSAAFICBSIndustryCode"].ToString();
                            item.IndustryHeader = dRow["IndustryHeader"].ToString();
                            item.IndustryDetail = dRow["IndustryDetail"].ToString();
                            item.NextRateReviewDateExtractedPerFaMSAAFICBS = dRow["NextRateReviewDateExtractedPerFaMSAAFICBS"].ToString();
                            item.PreviousMonthsNPLTaggingByRisk = dRow["PreviousMonthsNPLTaggingByRisk"].ToString();
                            item.SpecificRequiredProvisions = dRow["SpecificRequiredProvisions"].ToString();
                            item.GeneralRequiredProvisions = dRow["GeneralRequiredProvisions"].ToString();

                            ++count;
                            context = AddToContext(context, item, count, 100, true);

                        });

                        #endregion

                        context.SaveChanges();
                    }
                    finally
                    {
                        if (context != null)
                            context.Dispose();
                    }

                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
               // scope.Rollback();
                throw ex;
            }
        }

        private NTC_Context_Entities AddToContext(NTC_Context_Entities context, BDOLF_Consolidator aafmodel, int count, int commitCount, bool recreateContext)
        {
            context.Set<BDOLF_Consolidator>().Add(aafmodel);
            
            if (count % commitCount == 0)
            {
                context.SaveChanges();
                if (recreateContext)
                {
                    context.Dispose();
                    context = new NTC_Context_Entities();
                    context.Configuration.AutoDetectChangesEnabled = false;
                }
            }


            return context;
        }

        public void BulkUpdete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public bool ConsoChecker(string keyword)
        {
            // var result = context.BDOLF_Consolidator.Where(a => a.RecordDate.Contains(keyword)).Any();
            return context.BDOLF_Consolidator.Where(a => a.RecordDate.Contains(keyword)).Any();
        }

        public void DeleteFilePathMaintenace(string TransID)
        {
            throw new NotImplementedException();
        }

        public void DeleteFilePathMaintenace(int PathID)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_Consolidator> GetAll()
        {
            var query = from data in context.BDOLF_Consolidator.ToList()
                        select data;

            return query;
        }

        public BDOLF_Consolidator GetByCode(string PathID)
        {
            throw new NotImplementedException();
        }

        public BDOLF_Consolidator GetByID(int PathID)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_Consolidator> GetTopOne()
        {
            var query = from data in context.BDOLF_Consolidator.OrderByDescending(t => t.TransDate).Take(1)
                        select data;

            return query;
        }

        public void InsertFilePathMaintenace(BDOLF_Consolidator gl)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateFilePathMaintenace(BDOLF_PathMaintenance gl)
        {
            throw new NotImplementedException();
        }
    }
}
