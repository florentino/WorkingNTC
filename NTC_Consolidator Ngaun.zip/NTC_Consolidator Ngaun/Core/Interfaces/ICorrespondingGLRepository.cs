﻿using NTC_Consolidator.Data;
using NTC_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.Data;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface ICorrespondingGLRepository : IDisposable
    {
        IEnumerable<BDOLF_CorrepondingGL> GetGL();
        BDOLF_CorrepondingGL GetCorrespondingGLByID(int glCode);
        BDOLF_CorrepondingGL GetCorrespondingGLByID(string glCode);
        void InsertCorrespondingGL(BDOLF_CorrepondingGL gl);
        void DeleteCorrespondingGL(int glCode);
        void DeleteCorrespondingGL(string glCode);
        void UpdateCorrespondingGL(BDOLF_CorrepondingGL gl);
        void Save();
    }
}
