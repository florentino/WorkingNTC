﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmExchangeRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExchangeRate));
            this.lblErrRate = new MetroFramework.Controls.MetroLabel();
            this.lblErrCurrType = new MetroFramework.Controls.MetroLabel();
            this.txtRate = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnSubmit = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cmbDescription = new MetroFramework.Controls.MetroComboBox();
            this.dtPicker = new MetroFramework.Controls.MetroDateTime();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvRate = new MetroFramework.Controls.MetroGrid();
            this.Grv_Context = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExport = new MetroFramework.Controls.MetroButton();
            this.btnClose = new MetroFramework.Controls.MetroButton();
            this.picInfo = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRate)).BeginInit();
            this.Grv_Context.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblErrRate
            // 
            this.lblErrRate.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrRate.ForeColor = System.Drawing.Color.Red;
            this.lblErrRate.Location = new System.Drawing.Point(30, 204);
            this.lblErrRate.Name = "lblErrRate";
            this.lblErrRate.Size = new System.Drawing.Size(278, 19);
            this.lblErrRate.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrRate.TabIndex = 27;
            this.lblErrRate.UseStyleColors = true;
            // 
            // lblErrCurrType
            // 
            this.lblErrCurrType.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrCurrType.ForeColor = System.Drawing.Color.Red;
            this.lblErrCurrType.Location = new System.Drawing.Point(29, 130);
            this.lblErrCurrType.Name = "lblErrCurrType";
            this.lblErrCurrType.Size = new System.Drawing.Size(278, 19);
            this.lblErrCurrType.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrCurrType.TabIndex = 26;
            this.lblErrCurrType.UseStyleColors = true;
            // 
            // txtRate
            // 
            this.txtRate.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtRate.CustomButton.Image = null;
            this.txtRate.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtRate.CustomButton.Name = "";
            this.txtRate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtRate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRate.CustomButton.TabIndex = 1;
            this.txtRate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtRate.CustomButton.UseSelectable = true;
            this.txtRate.CustomButton.Visible = false;
            this.txtRate.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtRate.Lines = new string[0];
            this.txtRate.Location = new System.Drawing.Point(30, 178);
            this.txtRate.MaxLength = 32767;
            this.txtRate.Name = "txtRate";
            this.txtRate.PasswordChar = '\0';
            this.txtRate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtRate.SelectedText = "";
            this.txtRate.SelectionLength = 0;
            this.txtRate.SelectionStart = 0;
            this.txtRate.Size = new System.Drawing.Size(278, 23);
            this.txtRate.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRate.TabIndex = 25;
            this.txtRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRate.UseSelectable = true;
            this.txtRate.WaterMark = "0.0000";
            this.txtRate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtRate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRate_KeyPress);
            this.txtRate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.txtRate_MouseDown);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(30, 156);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(35, 19);
            this.metroLabel3.TabIndex = 24;
            this.metroLabel3.Text = "Rate";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(363, 489);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(61, 34);
            this.btnSubmit.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSubmit.TabIndex = 20;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseSelectable = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(29, 76);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(93, 19);
            this.metroLabel2.TabIndex = 30;
            this.metroLabel2.Text = "Currency Type";
            // 
            // cmbDescription
            // 
            this.cmbDescription.DropDownHeight = 80;
            this.cmbDescription.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDescription.FormattingEnabled = true;
            this.cmbDescription.IntegralHeight = false;
            this.cmbDescription.ItemHeight = 23;
            this.cmbDescription.Location = new System.Drawing.Point(30, 98);
            this.cmbDescription.MaxDropDownItems = 20;
            this.cmbDescription.Name = "cmbDescription";
            this.cmbDescription.Size = new System.Drawing.Size(277, 29);
            this.cmbDescription.Sorted = true;
            this.cmbDescription.TabIndex = 31;
            this.cmbDescription.UseSelectable = true;
            this.cmbDescription.UseStyleColors = true;
            this.cmbDescription.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmbDescription_MouseDown);
            // 
            // dtPicker
            // 
            this.dtPicker.Location = new System.Drawing.Point(7, 54);
            this.dtPicker.MinimumSize = new System.Drawing.Size(0, 29);
            this.dtPicker.Name = "dtPicker";
            this.dtPicker.Size = new System.Drawing.Size(10, 29);
            this.dtPicker.Style = MetroFramework.MetroColorStyle.Yellow;
            this.dtPicker.TabIndex = 32;
            this.dtPicker.UseCustomBackColor = true;
            this.dtPicker.UseCustomForeColor = true;
            this.dtPicker.UseStyleColors = true;
            this.dtPicker.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgvRate);
            this.panel1.Location = new System.Drawing.Point(30, 256);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(394, 199);
            this.panel1.TabIndex = 34;
            // 
            // dgvRate
            // 
            this.dgvRate.AllowUserToAddRows = false;
            this.dgvRate.AllowUserToDeleteRows = false;
            this.dgvRate.AllowUserToResizeRows = false;
            this.dgvRate.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRate.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvRate.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvRate.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRate.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvRate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRate.ContextMenuStrip = this.Grv_Context;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvRate.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvRate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRate.EnableHeadersVisualStyles = false;
            this.dgvRate.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvRate.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvRate.Location = new System.Drawing.Point(0, 0);
            this.dgvRate.Name = "dgvRate";
            this.dgvRate.ReadOnly = true;
            this.dgvRate.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvRate.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvRate.RowHeadersVisible = false;
            this.dgvRate.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvRate.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvRate.Size = new System.Drawing.Size(392, 197);
            this.dgvRate.TabIndex = 34;
            this.dgvRate.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRate_CellClick);
            this.dgvRate.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRate_CellLeave);
            this.dgvRate.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvRate_CellMouseDown);
            this.dgvRate.MouseLeave += new System.EventHandler(this.dgvRate_MouseLeave);
            // 
            // Grv_Context
            // 
            this.Grv_Context.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.Grv_Context.Name = "Grv_Context";
            this.Grv_Context.Size = new System.Drawing.Size(105, 48);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("editToolStripMenuItem.Image")));
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.editToolStripMenuItem.Text = "Edit";
            this.editToolStripMenuItem.Click += new System.EventHandler(this.editToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("deleteToolStripMenuItem.Image")));
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(104, 22);
            this.deleteToolStripMenuItem.Text = "delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // btnExport
            // 
            this.btnExport.Location = new System.Drawing.Point(188, 489);
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(102, 34);
            this.btnExport.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnExport.TabIndex = 35;
            this.btnExport.Text = "&Export To Excel";
            this.btnExport.UseSelectable = true;
            this.btnExport.Click += new System.EventHandler(this.btnExport_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(296, 489);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(61, 34);
            this.btnClose.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnClose.TabIndex = 36;
            this.btnClose.Text = "&Close";
            this.btnClose.UseSelectable = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // picInfo
            // 
            this.picInfo.Image = ((System.Drawing.Image)(resources.GetObject("picInfo.Image")));
            this.picInfo.Location = new System.Drawing.Point(309, 183);
            this.picInfo.Name = "picInfo";
            this.picInfo.Size = new System.Drawing.Size(16, 16);
            this.picInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picInfo.TabIndex = 37;
            this.picInfo.TabStop = false;
            this.picInfo.Tag = "Click Data Grid to cancel editing.";
            this.picInfo.Click += new System.EventHandler(this.picInfo_Click);
            this.picInfo.MouseHover += new System.EventHandler(this.pictureBox1_MouseHover);
            // 
            // frmExchangeRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 531);
            this.Controls.Add(this.picInfo);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnExport);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.cmbDescription);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblErrRate);
            this.Controls.Add(this.lblErrCurrType);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.dtPicker);
            this.MaximizeBox = false;
            this.Name = "frmExchangeRate";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "Exchange Rate";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmExchangeRate_FormClosed);
            this.Load += new System.EventHandler(this.frmExchangeRate_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRate)).EndInit();
            this.Grv_Context.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblErrRate;
        private MetroFramework.Controls.MetroLabel lblErrCurrType;
        private MetroFramework.Controls.MetroTextBox txtRate;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel cmbCurrencyType;
        private MetroFramework.Controls.MetroButton btnSubmit;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cmbDescription;
        private MetroFramework.Controls.MetroDateTime dtPicker;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroGrid dgvRate;
        private MetroFramework.Controls.MetroButton btnExport;
        private MetroFramework.Controls.MetroButton btnClose;
        private System.Windows.Forms.ContextMenuStrip Grv_Context;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.PictureBox picInfo;
    }
}