﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmMigratedAccount : MetroFramework.Forms.MetroForm
    {
        private static frmMigratedAccount frmmigratedAccount = null;
        private IMigratedAccount migratedAccountRepository;
        private string _underLitigation = "";
        string underLitigationFileName = "";
        private string _underLitigationEXT = "";
        private string _underLitigationDateParameter = "";
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtunderLitigation;
        DataTable dtRecords = new DataTable();
        string[] progressArray = new string[5];

        public static frmMigratedAccount Instance()
        {
            if (frmmigratedAccount == null)
            {
                frmmigratedAccount = new frmMigratedAccount();
            }
            return frmmigratedAccount;
        }


        public frmMigratedAccount()
        {
            InitializeComponent();
            this.migratedAccountRepository = new UnderLitigationRepository(new NTC_Context_Entities());
            lblBusy.Text = "";

            pnlWaitInfo.Location = new Point(
            this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
            this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }

        private void frmMigratedAccount_Load(object sender, EventArgs e)
        {

        }
    }
}
