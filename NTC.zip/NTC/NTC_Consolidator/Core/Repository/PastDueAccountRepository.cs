﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Repository
{
    public class PastDueAccountRepository
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public MigratedAccountRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }
    }
}
