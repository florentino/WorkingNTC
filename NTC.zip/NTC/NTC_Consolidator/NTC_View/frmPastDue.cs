﻿using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPastDue : MetroFramework.Forms.MetroForm
    {
        private static frmPastDue frmpastDue = null;
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;

        NumberStyles styles;

        string[] progressArray = new string[5];

        private IPastDueAccount pastDueAccountRepository;

        public static frmPastDue Instance()
        {
            if (frmpastDue == null)
            {
                frmpastDue = new frmPastDue();
            }
            return frmpastDue;
        }


        public frmPastDue()
        {
            InitializeComponent();
            this.pastDueAccountRepository = new MigratedAccountRepository(new NTC_Context_Entities());

            pnlWaitInfo.Location = new Point(
           this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            pnlSummary.Location = new Point(
           this.ClientSize.Width / 2 - pnlSummary.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlSummary.Size.Height / 2);
            pnlSummary.Visible = false;

            pnlInsertUpdate.Location = new Point(
          this.ClientSize.Width / 2 - pnlInsertUpdate.Size.Width / 2,
          this.ClientSize.Height / 2 - pnlInsertUpdate.Size.Height / 2);
            pnlInsertUpdate.Visible = false;
            lblBusy.Text = "";

        }

        private void frmPastDue_Load(object sender, EventArgs e)
        {

        }
    }
}
